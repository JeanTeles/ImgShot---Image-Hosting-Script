<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


function filter($data) {
    $data = trim(htmlentities(strip_tags($data)));

    if (get_magic_quotes_gpc())
        $data = stripslashes($data);

    $data = mysql_real_escape_string($data);

    return $data;
}

function limitedChars($string){
    if (preg_match("/[^-a-z 0-9_.-]/i", $string)) {
        return false;
    } else {
        return true;
    }
}

function banIPcheck(){
    $q = "SELECT reason FROM banned_ip WHERE ip LIKE '{$_SERVER['REMOTE_ADDR']}'";
    $result = mysql_query($q);
    if($result && mysql_num_rows($result) > 0) {
        $rowReason = mysql_fetch_assoc($result);
        if(isset($_SESSION['user_id'])) {
            header('Location: logout.php');
        }
        die($rowReason['reason']);
    }
}



function sendMail($address, $username, $subject, $message){
global $site_name;
    require_once('phpmail/class.phpmailer.php');
    //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded


    $mail             = new PHPMailer();

    //$body             = file_get_contents('contents.html');
    //$body             = eregi_replace("[\]",'',$body);

    $mail->IsSMTP(); // telling the class to use SMTP
    //$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    // 1 = errors and messages
    // 2 = messages only
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->Host       = PHPMAIL_HOST; // sets the SMTP server
    $mail->Port       = PHPMAIL_PORT;                    // set the SMTP port for the GMAIL server
    $mail->Username   = PHPMAIL_MAIL; // SMTP account username
    $mail->Password   = PHPMAIL_PASSWORD;        // SMTP account password

    $mail->SetFrom(PHPMAIL_MAIL, $site_name);
    $mail->AddReplyTo(PHPMAIL_MAIL, $site_name);
    $mail->Subject    = "$subject - $site_name";
    $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
    //$mail->AltBody($message);
    //$mail->MsgHTML($body);
    $mail->MsgHTML($message);
    //$mail->Body = $message;

    //$usernname = $_SESSION['user_name'];
    //$address = $rowUsers['user_email'];
    $mail->AddAddress($address, $username);

    //$mail->AddAttachment("images/phpmailer.gif");      // attachment
    //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

    if(!$mail->Send()) {
        return true;
        //echo "Mailer Error: " . $mail->ErrorInfo;

    } else {
        //echo "Message sent!";
        return false;
    }
}

/*
* File: SimpleImage.php
* Author: Simon Jarvis
* Copyright: 2006 Simon Jarvis
* Date: 08/11/06
* Link: http://www.white-hat-web-design.co.uk/articles/php-image-resizing.php
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details:
* http://www.gnu.org/licenses/gpl.html
*
*/

class SimpleImage {

    var $image;
    var $image_type;

    function load($filename) {
        $image_info = getimagesize($filename);
        $this->image_type = $image_info[2];
        if( $this->image_type == IMAGETYPE_JPEG ) {
            $this->image = imagecreatefromjpeg($filename);
        } elseif( $this->image_type == IMAGETYPE_GIF ) {
            $this->image = imagecreatefromgif($filename);
        } elseif( $this->image_type == IMAGETYPE_PNG ) {
            $this->image = imagecreatefrompng($filename);
        }
    }
    function save($filename, $image_type=IMAGETYPE_JPEG, $compression=75, $permissions=null) {
        if( $image_type == IMAGETYPE_JPEG ) {
            imagejpeg($this->image,$filename,$compression);
        } elseif( $image_type == IMAGETYPE_GIF ) {
            imagegif($this->image,$filename);
        } elseif( $image_type == IMAGETYPE_PNG ) {
            imagepng($this->image,$filename);
        }
        if( $permissions != null) {
            chmod($filename,$permissions);
        }
    }
    function output($image_type=IMAGETYPE_JPEG) {
        if( $image_type == IMAGETYPE_JPEG ) {
            imagejpeg($this->image);
        } elseif( $image_type == IMAGETYPE_GIF ) {
            imagegif($this->image);
        } elseif( $image_type == IMAGETYPE_PNG ) {
            imagepng($this->image);
        }
    }
    function getWidth() {
        return imagesx($this->image);
    }
    function getHeight() {
        return imagesy($this->image);
    }
    function resizeToHeight($height) {
        $ratio = $height / $this->getHeight();
        $width = $this->getWidth() * $ratio;
        $this->resize($width,$height);
    }
    function resizeToWidth($width) {
        $ratio = $width / $this->getWidth();
        $height = $this->getheight() * $ratio;
        $this->resize($width,$height);
    }
    function scale($scale) {
        $width = $this->getWidth() * $scale/100;
        $height = $this->getheight() * $scale/100;
        $this->resize($width,$height);
    }
    function resize($width,$height) {
        $new_image = imagecreatetruecolor($width, $height);
        imagecopyresampled($new_image, $this->image, 0, 0, 0, 0, $width, $height, $this->getWidth(), $this->getHeight());
        $this->image = $new_image;
    }
}


class login{
function page_protect() {
    session_start();

    global $db;

    /* Secure against Session Hijacking by checking user agent */
    if (isset($_SESSION['HTTP_USER_AGENT']))
    {
        if ($_SESSION['HTTP_USER_AGENT'] != md5($_SERVER['HTTP_USER_AGENT']))
        {
            $this->logout();
            exit;
        }
    }

    // before we allow sessions, we need to check authentication key - ckey and ctime stored in database

    /* If session not set, check for cookies set by Remember me */
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['user_name']) )
    {
        if(isset($_COOKIE['user_id']) && isset($_COOKIE['user_key'])){

            /* we double check cookie expiry time against stored in database */

            $cookie_user_id  = filter($_COOKIE['user_id']);
            $rs_ctime = mysql_query("select `ckey`,`ctime` from `users` where `id` ='$cookie_user_id'") or die(mysql_error());
            list($ckey,$ctime) = mysql_fetch_row($rs_ctime);
            // coookie expiry
            if( (time() - $ctime) > 60*60*24*COOKIE_TIME_OUT) {

                $this->logout();
            }
            /* Security check with untrusted cookies - dont trust value stored in cookie.
/* We also do authentication check of the `ckey` stored in cookie matches that stored in database during login*/

            if( !empty($ckey) && is_numeric($_COOKIE['user_id']) && $this->isUserID($_COOKIE['user_name']) && $_COOKIE['user_key'] == sha1($ckey)  ) {
                session_regenerate_id(); //against session fixation attacks.

                $_SESSION['user_id'] = $_COOKIE['user_id'];
                $_SESSION['user_name'] = $_COOKIE['user_name'];
                /* query user level from database instead of storing in cookies */
                list($user_level) = mysql_fetch_row(mysql_query("select user_level from users where id='$_SESSION[user_id]'"));

                $_SESSION['user_level'] = $user_level;
                $_SESSION['HTTP_USER_AGENT'] = md5($_SERVER['HTTP_USER_AGENT']);

            } else {
                $this->logout();
            }

        } else {
            header("Location: login.php");
            exit();
        }
    }

    // BANNING
    $userBanCheck = mysql_query("SELECT id FROM banned_users WHERE id_user = {$_SESSION['user_id']}");
    if($userBanCheck && mysql_num_rows($userBanCheck) > 0) {
        $this->logout();
    }
}



function EncodeURL($url)
{
    $new = strtolower(preg_replace(' ','_',$url));
    return($new);
}

function DecodeURL($url)
{
    $new = ucwords(preg_replace('_',' ',$url));
    return($new);
}

function ChopStr($str, $len)
{
    if (strlen($str) < $len)
        return $str;

    $str = substr($str,0,$len);
    if ($spc_pos = strrpos($str," "))
        $str = substr($str,0,$spc_pos);

    return $str . "...";
}

function isEmail($email){
    return preg_match('/^\S+@[\w\d.-]{2,}\.[\w]{2,6}$/iU', $email) ? TRUE : FALSE;
}

function isUserID($username)
{
    if (preg_match('/^[a-z\d_]{5,20}$/i', $username)) {
        return true;
    } else {
        return false;
    }
}

function isURL($url)
{
    if (preg_match('/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i', $url)) {
        return true;
    } else {
        return false;
    }
}

function checkPwd($x,$y)
{
    if(empty($x) || empty($y) ) { return false; }
    if (strlen($x) < 4 || strlen($y) < 4) { return false; }

    if (strcmp($x,$y) != 0) {
        return false;
    }
    return true;
}

function GenPwd($length = 7)
{
    $password = "";
    $possible = "0123456789bcdfghjkmnpqrstvwxyz"; //no vowels

    $i = 0;

    while ($i < $length) {


        $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);


        if (!strstr($password, $char)) {
            $password .= $char;
            $i++;
        }

    }

    return $password;

}

function GenKey($length = 7)
{
    $password = "";
    $possible = "0123456789abcdefghijkmnopqrstuvwxyz";

    $i = 0;

    while ($i < $length) {


        $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);


        if (!strstr($password, $char)) {
            $password .= $char;
            $i++;
        }

    }

    return $password;

}


function logout()
{
    global $db;
    session_start();

    if(isset($_SESSION['user_id']) || isset($_COOKIE['user_id'])) {
        mysql_query("update `users`
			set `ckey`= '', `ctime`= ''
			where `id`='$_SESSION[user_id]' OR  `id` = '$_COOKIE[user_id]'") or die(mysql_error());
    }

    /************ Delete the sessions****************/
    unset($_SESSION['user_id']);
    unset($_SESSION['user_name']);
    unset($_SESSION['user_level']);
    unset($_SESSION['HTTP_USER_AGENT']);
    session_unset();
    session_destroy();

    /* Delete the cookies*******************/
    setcookie("user_id", '', time()-60*60*24*COOKIE_TIME_OUT, "/");
    setcookie("user_name", '', time()-60*60*24*COOKIE_TIME_OUT, "/");
    setcookie("user_key", '', time()-60*60*24*COOKIE_TIME_OUT, "/");

    header("Location: login.php");
}

// Password and salt generation
function PwdHash($pwd, $salt = null)
{
    if ($salt === null)     {
        $salt = substr(md5(uniqid(rand(), true)), 0, SALT_LENGTH);
    }
    else     {
        $salt = substr($salt, 0, SALT_LENGTH);
    }
    return $salt . sha1($pwd . $salt);
}

function checkAdmin() {

    if($_SESSION['user_level'] == ADMIN_LEVEL) {
        return 1;
        } else {
        return 0 ;
        }
    }

}
class ZIP{
    function zipIsValid($path) {
        $zip = zip_open($path);
        if (is_resource($zip)) {
            // it's ok
            zip_close($zip); // always close handle if you were just checking
            return true;
        } else {
            return false;
        }
    }
    function zipFileUpload($inputname){
        global $uniquezipnamenumber;
        global $site_url;
        $ok=1;
        $upload_name = $inputname;
        // AICI VERIFICAM DACA A FOST ADAUGATA O FILA
        if (!isset($_FILES[$upload_name])) {
            //header('Location: index.php');
            echo 'No upload found in \$_FILES for ' . $upload_name;
            $ok=0;
            //exit();
        } else if (isset($_FILES[$upload_name]['error']) && $_FILES[$upload_name]['error'] != 0) {
            // echo $uploadErrors[$_FILES[$upload_name]['error']];
            echo "<p class='error'>No files</p>";
            $ok=0;
            //exit();
        } else if (!isset($_FILES[$upload_name]['tmp_name']) || !@is_uploaded_file($_FILES[$upload_name]['tmp_name'])) {
            echo "<p class='error'>Upload failed is_uploaded_file test.</p>";
            $ok=0;
            //exit();
        } else if (!isset($_FILES[$upload_name]['name'])) {
            $ok=0;
            echo "<p class='error'>File has no name.</p>";
            //exit();
        }

/*
        if($ok == 1) {
            // check if is a zip

            $imageinfo = getimagesize($_FILES[$upload_name]['tmp_name']);
            if($imageinfo['mime'] != 'application/zip') {
                echo "<p class='error'>That is not a ZIP file !</p>";
                $ok=0;
                //exit();
            }
        }
*/ // NEAPARAT DE REZOLVAT AICI
        if($ok == 1) {
            if($this->zipIsValid($_FILES[$upload_name]['tmp_name'])){
                $ok = 1;
            } else {
                $ok = 0;
                echo "<p class='error'>Invalid ZIP file</p>";
            }
        }



        if($ok == 1) {
            // blacklist ce nu tre sa fie
            $filename = strtolower($_FILES[$upload_name]['name']);
            $blacklist = array('php', 'php3', 'php4', 'phtml','exe'); #example of black list

            foreach ($blacklist as $item) {
                if(preg_match("/$item\$/i", $filename)) {
                    echo "<p class='error'>We do not allow uploading PHP files</p>";
                    $ok=0;
                    //exit();
                }
            }
        }

        if($ok == 1) {
            $dir = "cache/zip";

            if(!file_exists($dir) OR !is_dir($dir)){
                mkdir($dir, 0777, true);
            }

            //$uniquenumber = uniqid('', true);
            $uniquezipnamenumber = uniqid();

            $target = $dir;
            $extension = pathinfo($_FILES[$upload_name]['name'], PATHINFO_EXTENSION);
            //$filename =  $_FILES['uploaded']['name'];
            $target = $target  . "/"  . $uniquezipnamenumber . "." . $extension;


            $uploaded_size = $_FILES[$upload_name]['size'];

            //echo $uploaded_size;

            //This is our size condition
            if ($uploaded_size > MAX_UPLOAD_SIZE_ZIP*1024) {
                echo "<p class='error'>Your file is too large.</p>";
                $ok=0;
            }
        }
        //This is our limit file type condition



        if ($ok==0) {
            echo "<p class='error'>Sorry your file was not uploaded </p>";
        } else {

            //If everything is ok we try to upload it
            if(move_uploaded_file($_FILES[$upload_name]['tmp_name'], $target)) {
                echo "<p class='success'> ZIP file has been succesfuly uploaded </p>";

            } else {
                echo "<p class='error'>Sorry, there was a problem uploading your ZIP file.</p>";
            }
        }



    }

    function extract_upload($name, $destination){
        $zip = new ZipArchive;
        if ($zip->open($name) === TRUE) {
            $zip->extractTo($destination);
            $zip->close();
            //echo 'ok';
        } else {
            //echo 'failed';
        }
    }

    function delTree($dir) {
        $files = glob( $dir . '*', GLOB_MARK );
        foreach( $files as $file ){
            if( substr( $file, -1 ) == '/' )
                $this->delTree( $file );
            else
                unlink( $file );
        }
        rmdir( $dir );
    }
}

class FTP{
    function mkdir_recusive($con_id,$path){
        $parts = explode("/",$path);
        $return = true;
        $fullpath = "";
        foreach($parts as $part){
            if(empty($part)){
                $fullpath .= "/";
                continue;
            }
            $fullpath .= $part."/";
            if(@ftp_chdir($con_id, $fullpath)){
                ftp_chdir($con_id, $fullpath);
            }else{
                if(@ftp_mkdir($con_id, $part)){
                    ftp_chdir($con_id, $part);
                }else{
                    $return = false;
                }
            }
        }
        return $return;
    }
    function directory_exists($ftp, $dir)
    {
        // Get the current working directory
        $origin = ftp_pwd($ftp);

        // Attempt to change directory, suppress errors
        if (@ftp_chdir($ftp, $dir))
        {
            // If the directory exists, set back to origin
            ftp_chdir($ftp, $origin);
            return true;
        }

        // Directory does not exist
        return false;
    }

    function connect($ftp_server, $ftp_user, $ftp_pass) {

    global $ftp_conn_id;

        // set up a connection or die
        $ftp_conn_id = ftp_connect($ftp_server) or die("Couldn't connect to $ftp_server");

        // try to login
        if (@ftp_login($ftp_conn_id, $ftp_user, $ftp_pass)) {
            return true;
        } else {
            return false;
        }
    }
    function disconnect($ftp_conn_id){
        ftp_close($ftp_conn_id);
    }
}

class upload{
    function regular_upload($inputname, $ftp_server){
        global $site_url;
        $ok=1;
        $upload_name = $inputname;
        // AICI VERIFICAM DACA A FOST ADAUGATA O FILA
        if (!isset($_FILES[$upload_name])) {
            //header('Location: index.php');
            echo 'No upload found in \$_FILES for ' . $upload_name;
            $ok=0;
            //exit();
        } else if (isset($_FILES[$upload_name]['error']) && $_FILES[$upload_name]['error'] != 0) {
            // echo $uploadErrors[$_FILES[$upload_name]['error']];
            echo "<p class='error'>No files</p>";
            $ok=0;
            //exit();
        } else if (!isset($_FILES[$upload_name]['tmp_name']) || !@is_uploaded_file($_FILES[$upload_name]['tmp_name'])) {
            echo "<p class='error'>Upload failed is_uploaded_file test.</p>";
            $ok=0;
            //exit();
        } else if (!isset($_FILES[$upload_name]['name'])) {
            $ok=0;
            echo "<p class='error'>File has no name.</p>";
            //exit();
        }
        // DACA ADULT NU E NUMERIC DIEEEEE
        if (isset($_POST['adult']) && is_numeric($_POST['adult']) && $_POST['adult'] >= 0 && $_POST['adult'] <= 1) {
            $adult = $_POST['adult'];
        } else {
            die("You didn't specify if your file(s) are Adult or Non-Adult");
        }

        if(is_numeric($_POST['thumb_size_contaner'])) {
            $thumbnail_size = $_POST['thumb_size_contaner'];
        } else {
            die("Injection detected");
        }

        if($ok == 1) {
        // verificare tipul de imagini - un fel de whitelist
        $imageinfo = getimagesize($_FILES[$upload_name]['tmp_name']);
        if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg' && $imageinfo['mime'] != 'image/png' && $imageinfo['mime'] != 'image/jpg') {
            echo "<p class='error'>Sorry, we only accept GIF, JPEG and PNG images</p>";
            $ok=0;
            //exit();
        }
        }

        if($ok == 1) {
        // blacklist ce nu tre sa fie
        $filename = strtolower($_FILES[$upload_name]['name']);
        $blacklist = array('php', 'php3', 'php4', 'phtml','exe'); #example of black list

        foreach ($blacklist as $item) {
            if(preg_match("/$item\$/i", $filename)) {
                echo "<p class='error'>We do not allow uploading PHP files</p>";
                $ok=0;
                //exit();
            }
        }
        }

        if($ok == 1) {
        // de aici setam dimensiunea maxima a imaginii
        list($width, $height, $type, $attr) = getimagesize($_FILES[$upload_name]['tmp_name']);
        if ($width > MAX_UPLOAD_WIDTH || $height > MAX_UPLOAD_HEIGHT)
        {
            echo "<p class='error'>Maximum width and height exceeded. Please upload images below ".MAX_UPLOAD_WIDTH." x ".MAX_UPLOAD_HEIGHT." px size</p>";
            $ok=0;
            //exit();
        }
        }

        if($ok == 1) {
        $q = "SELECT img, thumb FROM sources WHERE id = '1'";
        $result = mysql_query($q);
        if(mysql_num_rows($result) > 0) {
            $rowSources = mysql_fetch_array($result);
        } else {
            die("Something went wrong : ". mysql_error());
        }



        $data_year = date('Y');
        $data_month = date('m');
        $data_day = date('d');

            if($ftp_server == 0) {
        $dir = $rowSources['img'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
        $dirthumb = $rowSources['thumb'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";

        if(!file_exists($dir) OR !is_dir($dir)){
            mkdir($dir, 0777, true);
        }

        if(!file_exists($dirthumb) OR !is_dir($dirthumb)){
            mkdir($dirthumb, 0777, true);
        }

        } else {
                $q = "SELECT * FROM ftp_logins
                INNER JOIN sources ON ftp_logins.source_id = sources.id
                WHERE ftp_logins.id = $ftp_server
                ";
                $result = mysql_query($q);
                if(!$result) {
                    echo mysql_error();
                }
                $rowFTP = mysql_fetch_assoc($result);

                $dir = $rowFTP['img'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dir2 = $rowFTP['img2'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dirthumb = $rowFTP['thumb'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dirthumb2 = $rowFTP['thumb2'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";



                $FTP = new FTP();
                $FTP->connect($rowFTP['host'], $rowFTP['user'], $rowFTP['pass']);
                global $ftp_conn_id;

                if(!$FTP->directory_exists($ftp_conn_id, "/". $dir)) {
                    $FTP->mkdir_recusive($ftp_conn_id, "/". $dir);
                }
                if(!$FTP->directory_exists($ftp_conn_id, "/". $dirthumb)) {
                    $FTP->mkdir_recusive($ftp_conn_id, "/". $dirthumb);
                }
            }

        //$uniquenumber = uniqid('', true);
        $uniquenumber = uniqid();
        $view_id = uniqid();

        $target = $dir;
        $extension = pathinfo($_FILES[$upload_name]['name'], PATHINFO_EXTENSION);
        //$filename =  $_FILES['uploaded']['name'];
        $nameimage = $uniquenumber . "." .  $extension;
        $target = $target  . "/"  . $uniquenumber . "." . $extension;


        $uploaded_size = $_FILES[$upload_name]['size'];

        //echo $uploaded_size;

        //This is our size condition
        if ($uploaded_size > MAX_UPLOAD_SIZE*1024) { // IN KB
            echo "<p class='error'>Your file is too large.</p>";
            $ok=0;
        }
        }
        //This is our limit file type condition



        if ($ok==0) {
            echo "<p class='error'>Sorry your file was not uploaded </p>";
        } else {

            //If everything is ok we try to upload it
if($ftp_server == 0) {

            if(move_uploaded_file($_FILES[$upload_name]['tmp_name'], $target)) {
                echo "<p class='success'> ". basename( $_FILES[$upload_name]['name']). " has been succesfuly uploaded </p>";

                //aici se transforma RESIZE PENTRU THUMBNAIL din $_POST[''];
                $thumbnail_size_final = 180;
                switch($thumbnail_size) {
                    case 1:
                        $thumbnail_size_final = SMALL_THUMB;
                        break;
                    case 2:
                        $thumbnail_size_final = MEDIUM_THUMB;
                        break;
                    case 3;
                        $thumbnail_size_final = LARGE_THUMB;
                        break;
                    case 4;
                        $thumbnail_size_final = LARGER_THUMB;
                        break;
                    case 5;
                        $thumbnail_size_final = COVER_THUMB;
                        break;
                }



                // aici se face resizeul imaginilor
                $target_thumb = $dirthumb;
                $resizeuploadpatch = $target_thumb . "/" . $uniquenumber . "." . $extension ;
                $image = new SimpleImage();
                $image->load($target);

                if($width > $thumbnail_size_final) {
                $image->resizeToWidth($thumbnail_size_final);
                }

                $image->save($resizeuploadpatch);


                $data = date('Y-m-d');
                //$ImageId = $randomnumber . "-" . $basenameFilesUploaded;
                //$ThumbSpreImagine = $website . "/" . $thumb . "/" . $ImageId;


                //INSERARE IN BAZA DE DATE
                if(isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                } else {
                    $user_id = 0;
                }

                if(isset($_SESSION['user_id']) && isset($_POST['set_gallery']) && is_numeric($_POST['set_gallery']) && strlen($_POST['set_gallery']) > 0) {
                    $qG = "SELECT id FROM galleries WHERE id = {$_POST['set_gallery']} AND id_user = {$_SESSION['user_id']}";
                    $resultQg = mysql_query($qG);
                    if($resultQg && mysql_num_rows($resultQg) > 0){
                        $gallery = $_POST['set_gallery'];
                    } else {
                        $gallery = 0;
                    }
                } else {
                    $gallery = 0;
                }

                $q = "INSERT INTO images (`id_user`,`gallery`,`name`,`view_id`, `date_added`, `last_view`, `source`, `adult`, `thumb_size`, `ftp`) VALUES
                            ('{$user_id}','{$gallery}','{$nameimage}', '{$view_id}', '{$data}', '{$data}', '1', '{$adult}', '{$thumbnail_size}', '{$ftp_server}')";
                $result = mysql_query($q);
                $id_inserted = mysql_insert_id();
                if(!$result) {
                    die("Database error : " . mysql_error());
                }

                if(isset($_POST['download_links']) && strlen($_POST['download_links']) > 2) {
                    $download_links = filter($_POST['download_links']);
                    $download_links = trim($download_links);
                    $q = "INSERT INTO images_opt (`id_img`, `download_links`) VALUES ('{$id_inserted}', '{$download_links}')";
                    $result = mysql_query($q);
                    if(!$result) {
                        die("Database error : " . mysql_error());
                    }
                }

                ?>

            <div id="uploadedimage">
                <a target='_blank' href="<?php echo "{$site_url}/img-{$view_id}.html"; ?>"><img border="0" src="<?php echo $site_url . "/" . $resizeuploadpatch; ?>" alt="uploaded_image" /></a>
            </div>

            <div id="uploadcodes">
                <label>BB Code:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL] "; ?>">
                <br /> <br />
                <label>HTML:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "<a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a> "; ?>">
                <br /> <br />
                <label>Link:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "{$site_url}/img-{$view_id}.html "; ?>">
                <?php
                if(DIRECT_LINK_SHOW == 1) {
                    echo "
                        <br /> <br />
                        <label>Direct Link to image:</label><br />
                        <input type='text' onclick='this.select();' value='{$site_url}/{$dir}/{$nameimage}'>
                        ";
                }
                ?>
            </div>

            <?php

                global $BBCode_global;
                global $HTMLCode_global;
                global $DirectLink_global;
                global $DirectLinkToImg_global;

                $BBCode_global[] = "[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL]";
                $HTMLCode_global[] = "<a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a>";
                $DirectLink_global[] = "{$site_url}/img-{$view_id}.html";
                $DirectLinkToImg_global[] = "{$site_url}/{$dir}/{$nameimage}";


                echo "<div style='display:none;' class='ajax_BBCode'>[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL]</div>";
                echo "<div style='display:none;' class='ajax_HTMLCode'><a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a></div>";
                echo "<div style='display:none;' class='ajax_DirectLink'>{$site_url}/img-{$view_id}.html</div>";
                echo "<div style='display:none;' class='ajax_DirectLinkToImg'>{$site_url}/{$dir}/{$nameimage}</div>";

            } else {
                echo "<p class='error'>Sorry, there was a problem uploading your file.</p>";
            }

} else { // if FTP SERVER
    $ftp_temp_img = "cache/ftp/".$nameimage."";
    $ftp_temp_thumb = "cache/ftp/thumb/".$nameimage."";
    if(move_uploaded_file($_FILES[$upload_name]['tmp_name'], $ftp_temp_img)) {
        //aici se transforma RESIZE PENTRU THUMBNAIL din $_POST[''];
        $thumbnail_size_final = 180;
        switch($thumbnail_size) {
            case 1:
                $thumbnail_size_final = SMALL_THUMB;
                break;
            case 2:
                $thumbnail_size_final = MEDIUM_THUMB;
                break;
            case 3;
                $thumbnail_size_final = LARGE_THUMB;
                break;
            case 4;
                $thumbnail_size_final = LARGER_THUMB;
                break;
            case 5;
                $thumbnail_size_final = COVER_THUMB;
                break;
        }



        // aici se face resizeul imaginilor
        $image = new SimpleImage();
        $image->load($ftp_temp_img);

        if($width > $thumbnail_size_final) {
            $image->resizeToWidth($thumbnail_size_final);
        }

        $image->save($ftp_temp_thumb);
    }


    if (ftp_put($ftp_conn_id, "/".$dir . "/$nameimage/", $ftp_temp_img, FTP_BINARY)) {
        //echo "successfully uploaded image $ftp_temp_img in $target\n";
    } else {
        //echo "There was a problem while uploading $ftp_temp_img in $target\n";
    }

    if (ftp_put($ftp_conn_id, "/".$dirthumb . "/$nameimage/", $ftp_temp_thumb, FTP_BINARY)) {
        //echo "successfully uploaded image $ftp_temp_thumb in $ftp_temp_thumb\n";
    } else {
        //echo "There was a problem while uploading $ftp_temp_thumb in $dirthumb\n";
    }

    $FTP->disconnect($ftp_conn_id);

    unlink($ftp_temp_img);
    unlink($ftp_temp_thumb);


    $data = date('Y-m-d');
    //$ImageId = $randomnumber . "-" . $basenameFilesUploaded;
    //$ThumbSpreImagine = $website . "/" . $thumb . "/" . $ImageId;


    //INSERARE IN BAZA DE DATE
    if(isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    } else {
        $user_id = 0;
    }

    if(isset($_SESSION['user_id']) && isset($_POST['set_gallery']) && is_numeric($_POST['set_gallery']) && strlen($_POST['set_gallery']) > 0) {
        $qG = "SELECT id FROM galleries WHERE id = {$_POST['set_gallery']} AND id_user = {$_SESSION['user_id']}";
        $resultQg = mysql_query($qG);
        if($resultQg && mysql_num_rows($resultQg) > 0){
            $gallery = $_POST['set_gallery'];
        } else {
            $gallery = 0;
        }
    } else {
        $gallery = 0;
    }

    $q = "INSERT INTO images (`id_user`,`gallery`,`name`,`view_id`, `date_added`, `last_view`, `source`, `adult`, `thumb_size`, `ftp`) VALUES
                            ('{$user_id}','{$gallery}','{$nameimage}', '{$view_id}', '{$data}', '{$data}', '{$rowFTP['source_id']}', '{$adult}', '{$thumbnail_size}', '{$ftp_server}')";
    $result = mysql_query($q);
    $id_inserted = mysql_insert_id();
    if(!$result) {
        die("Database error : " . mysql_error());
    }

    if(isset($_POST['download_links']) && strlen($_POST['download_links']) > 2) {
        $download_links = filter($_POST['download_links']);
        $download_links = trim($download_links);
        $q = "INSERT INTO images_opt (`id_img`, `download_links`) VALUES ('{$id_inserted}', '{$download_links}')";
        $result = mysql_query($q);
        if(!$result) {
            die("Database error : " . mysql_error());
        }
    }

    ?>

<div id="uploadedimage">
    <a target='_blank' href="<?php echo "{$site_url}/img-{$view_id}.html"; ?>"><img border="0" src="<?php echo "{$rowFTP['url']}/{$dirthumb2}/{$nameimage}"; ?>" alt="uploaded_image" /></a>
</div>

<div id="uploadcodes">
    <label>BB Code:</label><br />
    <input type='text' onclick="this.select();" value="<?php echo "[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL] "; ?>">
    <br /> <br />
    <label>HTML:</label><br />
    <input type='text' onclick="this.select();" value="<?php echo "<a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a> "; ?>">
    <br /> <br />
    <label>Link:</label><br />
    <input type='text' onclick="this.select();" value="<?php echo "{$site_url}/img-{$view_id}.html "; ?>">
    <?php
    if(DIRECT_LINK_SHOW == 1) {
        echo "
                        <br /> <br />
                        <label>Direct Link to image:</label><br />
                        <input type='text' onclick='this.select();' value='{$rowFTP['url']}/{$dir2}/{$nameimage}'>
                        ";
    }
    ?>
</div>

<?php

    global $BBCode_global;
    global $HTMLCode_global;
    global $DirectLink_global;
    global $DirectLinkToImg_global;

    $BBCode_global[] = "[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL]";
    $HTMLCode_global[] = "<a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a>";
    $DirectLink_global[] = "{$site_url}/img-{$view_id}.html";
    $DirectLinkToImg_global[] = "{$rowFTP['url']}/{$dir2}/{$nameimage}";

    echo "<div style='display:none;' class='ajax_BBCode'>[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL]</div>";
    echo "<div style='display:none;' class='ajax_HTMLCode'><a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a></div>";
    echo "<div style='display:none;' class='ajax_DirectLink'>{$site_url}/img-{$view_id}.html</div>";
    echo "<div style='display:none;' class='ajax_DirectLinkToImg'>{$rowFTP['url']}/{$dir2}/{$nameimage}</div>";

} // ftp end





        } // ELSE IF EVERYTING IS OK, IF ERROR = 0
    } // END FUNCTION

    function valid_url($str)
    {
        return ( ! preg_match('/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i', $str)) ? FALSE : TRUE;
    }

    function isImage($url)
    {
        $params = array('http' => array(
            'method' => 'HEAD'
        ));
        $ctx = stream_context_create($params);
        $fp = @fopen($url, 'rb', false, $ctx);
        if (!$fp)
            return false;  // Problem with url

        $meta = stream_get_meta_data($fp);
        if ($meta === false)
        {
            fclose($fp);
            return false;  // Problem reading data from url
        }

        $wrapper_data = $meta["wrapper_data"];
        if(is_array($wrapper_data)){
            foreach(array_keys($wrapper_data) as $hh){
                if (substr($wrapper_data[$hh], 0, 19) == "Content-Type: image") // strlen("Content-Type: image") == 19
                {
                    fclose($fp);
                    return true;
                }
            }
        }

        fclose($fp);
        return false;
    }

    function remoteUpload($url, $ftp_server){
        global $site_url;
        $ok = 1;
        if(!$this->valid_url($url) || !$this->isImage($url)) {
        $ok = 0;
            echo "Image or URL not valid";
        }

        // DACA ADULT NU E NUMERIC DIEEEEE
        if (isset($_POST['adult']) && is_numeric($_POST['adult']) && $_POST['adult'] >= 0 && $_POST['adult'] <= 1) {
            $adult = $_POST['adult'];
        } else {
            die("You didn't specify if your file(s) are Adult or Non-Adult");
        }

        if(is_numeric($_POST['thumb_size_contaner'])) {
            $thumbnail_size = $_POST['thumb_size_contaner'];
        } else {
            die("Injection detected");
        }

        if($ok == 1) {
            // verificare tipul de imagini - un fel de whitelist
            $imageinfo = getimagesize($url);
            if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg' && $imageinfo['mime'] != 'image/png' && $imageinfo['mime'] != 'image/jpg') {
                echo "<p class='error'>Sorry, we only accept GIF, JPEG and PNG images</p>";
                $ok=0;
                //exit();
            }
        }



        if($ok == 1) {
            // de aici setam dimensiunea maxima a imaginii
            list($width, $height, $type, $attr) = getimagesize($url);
            if ($width > MAX_UPLOAD_WIDTH || $height > MAX_UPLOAD_HEIGHT)
            {
                echo "<p class='error'>Maximum width and height exceeded. Please upload images below ".MAX_UPLOAD_WIDTH." x ".MAX_UPLOAD_HEIGHT." px size</p>";
                $ok=0;
                //exit();
            }
        }
        if($ok == 1) {
            $path_upload = explode('/', $url);
            $nameupload=$path_upload[count($path_upload)-1];

            $q = "SELECT img, thumb FROM sources WHERE id = '1'";
            $result = mysql_query($q);
            if(mysql_num_rows($result) > 0) {
                $rowSources = mysql_fetch_array($result);
            } else {
                $ok=0;
                die("Something went wrong : ". mysql_error());
            }
        }

        if($ok == 1) {

            $data_year = date('Y');
            $data_month = date('m');
            $data_day = date('d');

            if($ftp_server == 0) {
            $dir = $rowSources['img'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
            $dirthumb = $rowSources['thumb'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";


            if(!file_exists($dir) OR !is_dir($dir)){
                mkdir($dir, 0777, true);
            }

            if(!file_exists($dirthumb) OR !is_dir($dirthumb)){
                mkdir($dirthumb, 0777, true);
            }

            } else {
                $q = "SELECT * FROM ftp_logins
                INNER JOIN sources ON ftp_logins.source_id = sources.id
                WHERE ftp_logins.id = $ftp_server
                ";
                $result = mysql_query($q);
                if(!$result) {
                    echo mysql_error();
                }
                $rowFTP = mysql_fetch_assoc($result);

                $dir = $rowFTP['img'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dir2 = $rowFTP['img2'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dirthumb = $rowFTP['thumb'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dirthumb2 = $rowFTP['thumb2'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";


                $FTP = new FTP();
                $FTP->connect($rowFTP['host'], $rowFTP['user'], $rowFTP['pass']);
                global $ftp_conn_id;

                if(!$FTP->directory_exists($ftp_conn_id, "/". $dir)) {
                    $FTP->mkdir_recusive($ftp_conn_id, "/". $dir);
                }
                if(!$FTP->directory_exists($ftp_conn_id, "/". $dirthumb)) {
                    $FTP->mkdir_recusive($ftp_conn_id, "/". $dirthumb);
                }
            }

            //$uniquenumber = uniqid('', true);
            $uniquenumber = uniqid();
            $view_id = uniqid();

            $target = $dir;
            switch($imageinfo['mime']) {
                case 'image/gif':
                    $extension = "gif";
                    break;
                case 'image/jpeg':
                    $extension = "jpeg";
                    break;
                case 'image/png':
                    $extension = "png";
                    break;
                case 'image/jpg':
                    $extension = "jpg";
                    break;
            }
            //$extension = pathinfo($_FILES[$upload_name]['name'], PATHINFO_EXTENSION);
            //$filename =  $_FILES['uploaded']['name'];
            $target = $target  . "/"  . $uniquenumber . "." . $extension;
            $nameimage = $uniquenumber . "." .  $extension;


            //$uploaded_size = $_FILES[$upload_name]['size'];
            // NU MAI FILTRAM DIMENSIUNEA IMAGINII !!!!!!!!!!!!!!!!@@@@@@@@!!!!!!!!!!!

        }

        if ($ok==0) {
            echo "<p class='error'>Sorry your file was not uploaded </p>";
        } else {


            if($ftp_server == 0) {
        if(copy($url, $target)) {
            echo "<p class='success'> ". $nameupload . " has been succesfuly uploaded </p>";
            $thumbnail_size_final = 180;
            switch($thumbnail_size) {
                case 1:
                    $thumbnail_size_final = SMALL_THUMB;
                    $thumbnail_size_final_height = 100;
                    break;
                case 2:
                    $thumbnail_size_final = MEDIUM_THUMB;
                    $thumbnail_size_final_height = 200;
                    break;
                case 3;
                    $thumbnail_size_final = LARGE_THUMB;
                    $thumbnail_size_final_height = 300;
                    break;
                case 4;
                    $thumbnail_size_final = LARGER_THUMB;
                    $thumbnail_size_final_height = 400;
                    break;
            }

            // aici se face resizeul imaginilor
            $target_thumb = $dirthumb;
            $resizeuploadpatch = $target_thumb . "/" . $uniquenumber . "." . $extension ;
            $image = new SimpleImage();
            $image->load($target);
            if($width > $thumbnail_size_final) {
            $image->resizeToWidth($thumbnail_size_final);
            }
            $image->save($resizeuploadpatch);


            $data = date('Y-m-d');
            //$ImageId = $randomnumber . "-" . $basenameFilesUploaded;
            //$ThumbSpreImagine = $website . "/" . $thumb . "/" . $ImageId;


            //INSERARE IN BAZA DE DATE
            if(isset($_SESSION['user_id'])) {
                $user_id = $_SESSION['user_id'];
            } else {
                $user_id = 0;
            }

            $q = "INSERT INTO images (`id_user`,`name`,`view_id`, `date_added`, `last_view`, `source`, `adult`, `thumb_size`, `ftp`) VALUES
                            ('{$user_id}','{$nameimage}', '{$view_id}', '{$data}', '{$data}', '1', '{$adult}', '{$thumbnail_size}', '{$ftp_server}')";
            $result = mysql_query($q);
            $id_inserted = mysql_insert_id();
            if(!$result) {
                die("Database error : " . mysql_error());
            }

            if(isset($_POST['download_links']) && strlen($_POST['download_links']) > 2) {
                $download_links = filter($_POST['download_links']);
                $download_links = trim($download_links);
                $q = "INSERT INTO images_opt (`id_img`, `download_links`) VALUES ('{$id_inserted}', '{$download_links}')";
                $result = mysql_query($q);
                if(!$result) {
                    die("Database error : " . mysql_error());
                }
            }

            ?>

        <div id="uploadedimage">
            <a href="<?php echo "{$site_url}/img-{$view_id}.html"; ?>"><img border="0" src="<?php echo $site_url . "/" . $resizeuploadpatch; ?>" alt="uploaded_image" /></a>
        </div>

        <div id="uploadcodes">
            <label>BB Code:</label><br />
            <input type='text' onclick="this.select();" value="<?php echo "[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL]"; ?>">
            <br /> <br />
            <label>HTML:</label><br />
            <input type='text' onclick="this.select();" value="<?php echo "<a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a>"; ?>">
            <br /> <br />
            <label>Link:</label><br />
            <input type='text' onclick="this.select();" value="<?php echo "{$site_url}/img-{$view_id}.html"; ?>">
            <?php
            if(DIRECT_LINK_SHOW == 1) {
                echo "
                        <br /> <br />
                        <label>Direct Link to image:</label><br />
                        <input type='text' onclick='this.select();' value='{$site_url}/{$dir}/{$nameimage}'>
                        ";
            }
            ?>
        </div>

        <?php


        } else {
            echo "<p class='error'>Sorry, there was a problem uploading your file.</p>";
        }


            } else { // ELSE FTP SERVER IS NOT 0


                $ftp_temp_img = "cache/ftp/".$nameimage."";
                $ftp_temp_thumb = "cache/ftp/thumb/".$nameimage."";

                if(copy($url, $ftp_temp_img)) {
                    //aici se transforma RESIZE PENTRU THUMBNAIL din $_POST[''];
                    $thumbnail_size_final = 180;
                    switch($thumbnail_size) {
                        case 1:
                            $thumbnail_size_final = SMALL_THUMB;
                            break;
                        case 2:
                            $thumbnail_size_final = MEDIUM_THUMB;
                            break;
                        case 3;
                            $thumbnail_size_final = LARGE_THUMB;
                            break;
                        case 4;
                            $thumbnail_size_final = LARGER_THUMB;
                            break;
                        case 5;
                            $thumbnail_size_final = COVER_THUMB;
                            break;
                    }



                    // aici se face resizeul imaginilor
                    $image = new SimpleImage();
                    $image->load($ftp_temp_img);

                    if($width > $thumbnail_size_final) {
                        $image->resizeToWidth($thumbnail_size_final);
                    }

                    $image->save($ftp_temp_thumb);



                if (ftp_put($ftp_conn_id, "/".$dir . "/$nameimage/", $ftp_temp_img, FTP_BINARY)) {
                    //echo "successfully uploaded image $ftp_temp_img in $target\n";
                } else {
                    //echo "There was a problem while uploading $ftp_temp_img in $target\n";
                }

                if (ftp_put($ftp_conn_id, "/".$dirthumb . "/$nameimage/", $ftp_temp_thumb, FTP_BINARY)) {
                    //echo "successfully uploaded image $ftp_temp_thumb in $ftp_temp_thumb\n";
                } else {
                    //echo "There was a problem while uploading $ftp_temp_thumb in $dirthumb\n";
                }

                $FTP->disconnect($ftp_conn_id);

                unlink($ftp_temp_img);
                unlink($ftp_temp_thumb);


                $data = date('Y-m-d');
                //$ImageId = $randomnumber . "-" . $basenameFilesUploaded;
                //$ThumbSpreImagine = $website . "/" . $thumb . "/" . $ImageId;


                //INSERARE IN BAZA DE DATE
                if(isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                } else {
                    $user_id = 0;
                }

                if(isset($_SESSION['user_id']) && isset($_POST['set_gallery']) && is_numeric($_POST['set_gallery']) && strlen($_POST['set_gallery']) > 0) {
                    $qG = "SELECT id FROM galleries WHERE id = {$_POST['set_gallery']} AND id_user = {$_SESSION['user_id']}";
                    $resultQg = mysql_query($qG);
                    if($resultQg && mysql_num_rows($resultQg) > 0){
                        $gallery = $_POST['set_gallery'];
                    } else {
                        $gallery = 0;
                    }
                } else {
                    $gallery = 0;
                }

                $q = "INSERT INTO images (`id_user`,`gallery`,`name`,`view_id`, `date_added`, `last_view`, `source`, `adult`, `thumb_size`, `ftp`) VALUES
                            ('{$user_id}','{$gallery}','{$nameimage}', '{$view_id}', '{$data}', '{$data}', '{$rowFTP['source_id']}', '{$adult}', '{$thumbnail_size}', '{$ftp_server}')";
                $result = mysql_query($q);
                $id_inserted = mysql_insert_id();
                if(!$result) {
                    die("Database error : " . mysql_error());
                }

                if(isset($_POST['download_links']) && strlen($_POST['download_links']) > 2) {
                    $download_links = filter($_POST['download_links']);
                    $download_links = trim($download_links);
                    $q = "INSERT INTO images_opt (`id_img`, `download_links`) VALUES ('{$id_inserted}', '{$download_links}')";
                    $result = mysql_query($q);
                    if(!$result) {
                        die("Database error : " . mysql_error());
                    }
                }

                ?>

            <div id="uploadedimage">
                <a target='_blank' href="<?php echo "{$site_url}/img-{$view_id}.html"; ?>"><img border="0" src="<?php echo "{$rowFTP['url']}/{$dirthumb2}/{$nameimage}"; ?>" alt="uploaded_image" /></a>
            </div>

            <div id="uploadcodes">
                <label>BB Code:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL] "; ?>">
                <br /> <br />
                <label>HTML:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "<a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a> "; ?>">
                <br /> <br />
                <label>Link:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "{$site_url}/img-{$view_id}.html "; ?>">
                <?php
                if(DIRECT_LINK_SHOW == 1) {
                    echo "
                        <br /> <br />
                        <label>Direct Link to image:</label><br />
                        <input type='text' onclick='this.select();' value='{$rowFTP['url']}/{$dir2}/{$nameimage}'>
                        ";
                }
                ?>
            </div>

            <?php

                global $BBCode_global;
                global $HTMLCode_global;
                global $DirectLink_global;
                global $DirectLinkToImg_global;

                $BBCode_global[] = "[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL]";
                $HTMLCode_global[] = "<a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a>";
                $DirectLink_global[] = "{$site_url}/img-{$view_id}.html";
                $DirectLinkToImg_global[] = "{$rowFTP['url']}/{$dir2}/{$nameimage}";

                echo "<div style='display:none;' class='ajax_BBCode'>[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL]</div>";
                echo "<div style='display:none;' class='ajax_HTMLCode'><a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a></div>";
                echo "<div style='display:none;' class='ajax_DirectLink'>{$site_url}/img-{$view_id}.html</div>";
                echo "<div style='display:none;' class='ajax_DirectLink'>{$rowFTP['url']}/{$dir2}/{$nameimage}</div>";




                } else {
                    echo "<p class='error'>Sorry, there was a problem uploading your file.</p>";
                }
          }

        } // ELSE IF EVERYTING IS OK, IF ERROR = 0
    } // END FUNCTION





    function zipUpload($patch, $ftp_server){
        global $site_url;
        $ok = 1;

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            //echo 'This is a server using Windows!';
            if(!file_exists($patch)) {
                $ok = 0;
                echo "File " . $patch . " does not exist";

            }
        } else {
            //echo 'This is a server not using Windows!';
            if(!file_exists($_SERVER['DOCUMENT_ROOT']  . "/" . $patch)) {
                $ok = 0;
                echo "File " . $_SERVER['DOCUMENT_ROOT'] . "/"  . $patch . " does not exist";

            }
        }




        //TEMP DELETE
        $_POST['adult'] = 0;
        $_POST['thumb_size_contaner'] = 2;
        // END TEMP DELETE
        // DACA ADULT NU E NUMERIC DIEEEEE
        if (isset($_POST['adult']) && is_numeric($_POST['adult']) && $_POST['adult'] >= 0 && $_POST['adult'] <= 1) {
            $adult = $_POST['adult'];
        } else {
            die("You didn't specify if your file(s) are Adult or Non-Adult");
        }

        if(is_numeric($_POST['thumb_size_contaner'])) {
            $thumbnail_size = $_POST['thumb_size_contaner'];
        } else {
            die("Injection detected");
        }

        if($ok == 1) {
            // verificare tipul de imagini - un fel de whitelist
            $imageinfo = getimagesize($patch);
            if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg' && $imageinfo['mime'] != 'image/png' && $imageinfo['mime'] != 'image/jpg') {
                echo "<p class='error'>Sorry, we only accept GIF, JPEG and PNG images</p>";
                $ok=0;
                //exit();
            }
        }



        if($ok == 1) {
            // de aici setam dimensiunea maxima a imaginii
            list($width, $height, $type, $attr) = getimagesize($patch);
            if ($width > MAX_UPLOAD_WIDTH || $height > MAX_UPLOAD_HEIGHT)
            {
                echo "<p class='error'>Maximum width and height exceeded. Please upload images below ".MAX_UPLOAD_WIDTH." x ".MAX_UPLOAD_HEIGHT." px size</p>";
                $ok=0;
                //exit();
            }
        }
        if($ok == 1) {
            $path_upload = explode('/', $patch);
            $nameupload=$path_upload[count($path_upload)-1];

            $q = "SELECT img, thumb FROM sources WHERE id = '1'";
            $result = mysql_query($q);
            if(mysql_num_rows($result) > 0) {
                $rowSources = mysql_fetch_array($result);
            } else {
                $ok=0;
                die("Something went wrong : ". mysql_error());
            }
        }

        if($ok == 1) {

            $data_year = date('Y');
            $data_month = date('m');
            $data_day = date('d');

            if($ftp_server == 0) {
            $dir = $rowSources['img'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
            $dirthumb = $rowSources['thumb'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";

            if(!file_exists($dir) OR !is_dir($dir)){
                mkdir($dir, 0777, true);
            }

            if(!file_exists($dirthumb) OR !is_dir($dirthumb)){
                mkdir($dirthumb, 0777, true);
            }

            } else {
                $q = "SELECT * FROM ftp_logins
                INNER JOIN sources ON ftp_logins.source_id = sources.id
                WHERE ftp_logins.id = $ftp_server
                ";
                $result = mysql_query($q);
                if(!$result) {
                    echo mysql_error();
                }
                $rowFTP = mysql_fetch_assoc($result);

                $dir = $rowFTP['img'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dir2 = $rowFTP['img2'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dirthumb = $rowFTP['thumb'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";
                $dirthumb2 = $rowFTP['thumb2'] . "/" . $data_year . "/" . $data_month . "/" . "$data_day";



                $FTP = new FTP();
                $FTP->connect($rowFTP['host'], $rowFTP['user'], $rowFTP['pass']);
                global $ftp_conn_id;

                if(!$FTP->directory_exists($ftp_conn_id, "/". $dir)) {
                    $FTP->mkdir_recusive($ftp_conn_id, "/". $dir);
                }
                if(!$FTP->directory_exists($ftp_conn_id, "/". $dirthumb)) {
                    $FTP->mkdir_recusive($ftp_conn_id, "/". $dirthumb);
                }
            }

            //$uniquenumber = uniqid('', true);
            $uniquenumber = uniqid();
            $view_id = uniqid();

            $target = $dir;
            switch($imageinfo['mime']) {
                case 'image/gif':
                    $extension = "gif";
                    break;
                case 'image/jpeg':
                    $extension = "jpeg";
                    break;
                case 'image/png':
                    $extension = "png";
                    break;
                case 'image/jpg':
                    $extension = "jpg";
                    break;
            }
            //$extension = pathinfo($_FILES[$upload_name]['name'], PATHINFO_EXTENSION);
            //$filename =  $_FILES['uploaded']['name'];
            $target = $target  . "/"  . $uniquenumber . "." . $extension;
            $nameimage = $uniquenumber . "." .  $extension;


            //$uploaded_size = $_FILES[$upload_name]['size'];
            // NU MAI FILTRAM DIMENSIUNEA IMAGINII !!!!!!!!!!!!!!!!@@@@@@@@!!!!!!!!!!!

        }

        if ($ok==0) {
            echo "<p class='error'>Sorry your file was not uploaded </p>";
        } else {


            if($ftp_server == 0) {
            if(copy($patch, $target)) {
                echo "<p class='success'> ". $nameupload . " has been succesfuly uploaded </p>";
                $thumbnail_size_final = 180;
                switch($thumbnail_size) {
                    case 1:
                        $thumbnail_size_final = SMALL_THUMB;
                        $thumbnail_size_final_height = 100;
                        break;
                    case 2:
                        $thumbnail_size_final = MEDIUM_THUMB;
                        $thumbnail_size_final_height = 200;
                        break;
                    case 3;
                        $thumbnail_size_final = LARGE_THUMB;
                        $thumbnail_size_final_height = 300;
                        break;
                    case 4;
                        $thumbnail_size_final = LARGER_THUMB;
                        $thumbnail_size_final_height = 400;
                        break;
                }

                // aici se face resizeul imaginilor
                $target_thumb = $dirthumb;
                $resizeuploadpatch = $target_thumb . "/" . $uniquenumber . "." . $extension ;
                $image = new SimpleImage();
                $image->load($target);
                if($width > $thumbnail_size_final) {
                    $image->resizeToWidth($thumbnail_size_final);
                }
                $image->save($resizeuploadpatch);


                $data = date('Y-m-d');
                //$ImageId = $randomnumber . "-" . $basenameFilesUploaded;
                //$ThumbSpreImagine = $website . "/" . $thumb . "/" . $ImageId;


                //INSERARE IN BAZA DE DATE
                if(isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                } else {
                    $user_id = 0;
                }

                if(isset($_SESSION['user_id']) && isset($_POST['set_gallery']) && is_numeric($_POST['set_gallery']) && strlen($_POST['set_gallery']) > 0) {
                    $qG = "SELECT id FROM galleries WHERE id = {$_POST['set_gallery']} AND id_user = {$_SESSION['user_id']}";
                    $resultQg = mysql_query($qG);
                    if($resultQg && mysql_num_rows($resultQg) > 0){
                        $gallery = $_POST['set_gallery'];
                    } else {
                        $gallery = 0;
                    }
                } else {
                    $gallery = 0;
                }

                $q = "INSERT INTO images (`id_user`,`gallery`,`name`,`view_id`, `date_added`, `last_view`, `source`, `adult`, `thumb_size`, `ftp`) VALUES
                            ('{$user_id}','{$gallery}','{$nameimage}', '{$view_id}', '{$data}', '{$data}', '1', '{$adult}', '{$thumbnail_size}', '{$ftp_server}')";
                $result = mysql_query($q);
                $id_inserted = mysql_insert_id();
                if(!$result) {
                    die("Database error : " . mysql_error());
                }

                if(isset($_POST['download_links']) && strlen($_POST['download_links']) > 2) {
                    $download_links = filter($_POST['download_links']);
                    $download_links = trim($download_links);
                    $q = "INSERT INTO images_opt (`id_img`, `download_links`) VALUES ('{$id_inserted}', '{$download_links}')";
                    $result = mysql_query($q);
                    if(!$result) {
                        die("Database error : " . mysql_error());
                    }
                }

                ?>

            <div id="uploadedimage">
                <a target='_blank' href="<?php echo "{$site_url}/img-{$view_id}.html"; ?>"><img border="0" src="<?php echo $site_url . "/" . $resizeuploadpatch; ?>" alt="uploaded_image" /></a>
            </div>

            <div id="uploadcodes">
                <label>BB Code:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL] "; ?>">
                <br /> <br />
                <label>HTML:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "<a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a> "; ?>">
                <br /> <br />
                <label>Link:</label><br />
                <input type='text' onclick="this.select();" value="<?php echo "{$site_url}/img-{$view_id}.html "; ?>">
                <?php
                if(DIRECT_LINK_SHOW == 1) {
                    echo "
                        <br /> <br />
                        <label>Direct Link to image:</label><br />
                        <input type='text' onclick='this.select();' value='{$site_url}/{$dir}/{$nameimage}'>
                        ";
                }
                ?>
            </div>

            <?php

                global $BBCode_global;
                global $HTMLCode_global;
                global $DirectLink_global;
                global $DirectLinkToImg_global;

                $BBCode_global[] = "[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL]";
                $HTMLCode_global[] = "<a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a>";
                $DirectLink_global[] = "{$site_url}/img-{$view_id}.html";
                $DirectLinkToImg_global[] = "{$site_url}/{$dir}/{$nameimage}";

                echo "<div style='display:none;' class='ajax_BBCode'>[URL={$site_url}/img-{$view_id}.html][IMG]{$site_url}/{$resizeuploadpatch}[/IMG][/URL]</div>";
                echo "<div style='display:none;' class='ajax_HTMLCode'><a href='{$site_url}/img-{$view_id}.html'><img src='{$site_url}/{$resizeuploadpatch}' alt='image' /></a></div>";
                echo "<div style='display:none;' class='ajax_DirectLink'>{$site_url}/img-{$view_id}.html</div>";
                echo "<div style='display:none;' class='ajax_DirectLinkToImg'>{$site_url}/{$dir}/{$nameimage}</div>";

            } else {
                echo "<p class='error'>Sorry, there was a problem uploading your file.</p>";
            }

            } else { // ELSE FTP SERVER IS NOT 0

                $ftp_temp_img = "cache/ftp/".$nameimage."";
                $ftp_temp_thumb = "cache/ftp/thumb/".$nameimage."";

                if(copy($patch, $ftp_temp_img)) {
                    echo "<p class='success'> ". $nameupload . " has been succesfuly uploaded </p>";
                    $thumbnail_size_final = 180;
                    switch($thumbnail_size) {
                        case 1:
                            $thumbnail_size_final = SMALL_THUMB;
                            $thumbnail_size_final_height = 100;
                            break;
                        case 2:
                            $thumbnail_size_final = MEDIUM_THUMB;
                            $thumbnail_size_final_height = 200;
                            break;
                        case 3;
                            $thumbnail_size_final = LARGE_THUMB;
                            $thumbnail_size_final_height = 300;
                            break;
                        case 4;
                            $thumbnail_size_final = LARGER_THUMB;
                            $thumbnail_size_final_height = 400;
                            break;
                    }

                    // aici se face resizeul imaginilor

                    $image = new SimpleImage();
                    $image->load($ftp_temp_img);

                    if($width > $thumbnail_size_final) {
                        $image->resizeToWidth($thumbnail_size_final);
                    }

                    $image->save($ftp_temp_thumb);

                    if (ftp_put($ftp_conn_id, "/".$dir . "/$nameimage/", $ftp_temp_img, FTP_BINARY)) {
                        //echo "successfully uploaded image $ftp_temp_img in $target\n";
                    } else {
                        //echo "There was a problem while uploading $ftp_temp_img in $target\n";
                    }

                    if (ftp_put($ftp_conn_id, "/".$dirthumb . "/$nameimage/", $ftp_temp_thumb, FTP_BINARY)) {
                        //echo "successfully uploaded image $ftp_temp_thumb in $ftp_temp_thumb\n";
                    } else {
                        //echo "There was a problem while uploading $ftp_temp_thumb in $dirthumb\n";
                    }

                    $FTP->disconnect($ftp_conn_id);

                    unlink($ftp_temp_img);
                    unlink($ftp_temp_thumb);

                    $data = date('Y-m-d');
                    //$ImageId = $randomnumber . "-" . $basenameFilesUploaded;
                    //$ThumbSpreImagine = $website . "/" . $thumb . "/" . $ImageId;


                    //INSERARE IN BAZA DE DATE
                    if(isset($_SESSION['user_id'])) {
                        $user_id = $_SESSION['user_id'];
                    } else {
                        $user_id = 0;
                    }

                    if(isset($_SESSION['user_id']) && isset($_POST['set_gallery']) && is_numeric($_POST['set_gallery']) && strlen($_POST['set_gallery']) > 0) {
                        $qG = "SELECT id FROM galleries WHERE id = {$_POST['set_gallery']} AND id_user = {$_SESSION['user_id']}";
                        $resultQg = mysql_query($qG);
                        if($resultQg && mysql_num_rows($resultQg) > 0){
                            $gallery = $_POST['set_gallery'];
                        } else {
                            $gallery = 0;
                        }
                    } else {
                        $gallery = 0;
                    }

                    $q = "INSERT INTO images (`id_user`,`gallery`,`name`,`view_id`, `date_added`, `last_view`, `source`, `adult`, `thumb_size`, `ftp`) VALUES
                            ('{$user_id}','{$gallery}','{$nameimage}', '{$view_id}', '{$data}', '{$data}', '{$rowFTP['source_id']}', '{$adult}', '{$thumbnail_size}', '{$ftp_server}')";
                    $result = mysql_query($q);
                    $id_inserted = mysql_insert_id();
                    if(!$result) {
                        die("Database error : " . mysql_error());
                    }

                    if(isset($_POST['download_links']) && strlen($_POST['download_links']) > 2) {
                        $download_links = filter($_POST['download_links']);
                        $download_links = trim($download_links);
                        $q = "INSERT INTO images_opt (`id_img`, `download_links`) VALUES ('{$id_inserted}', '{$download_links}')";
                        $result = mysql_query($q);
                        if(!$result) {
                            die("Database error : " . mysql_error());
                        }
                    }

                    ?>

                <div id="uploadedimage">
                    <a target='_blank' href="<?php echo "{$site_url}/img-{$view_id}.html"; ?>"><img border="0" src="<?php echo "{$rowFTP['url']}/{$dirthumb2}/{$nameimage}"; ?>" alt="uploaded_image" /></a>
                </div>

                <div id="uploadcodes">
                    <label>BB Code:</label><br />
                    <input type='text' onclick="this.select();" value="<?php echo "[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL] "; ?>">
                    <br /> <br />
                    <label>HTML:</label><br />
                    <input type='text' onclick="this.select();" value="<?php echo "<a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a> "; ?>">
                    <br /> <br />
                    <label>Link:</label><br />
                    <input type='text' onclick="this.select();" value="<?php echo "{$site_url}/img-{$view_id}.html "; ?>">
                    <?php
                    if(DIRECT_LINK_SHOW == 1) {
                        echo "
                        <br /> <br />
                        <label>Direct Link to image:</label><br />
                        <input type='text' onclick='this.select();' value='{$rowFTP['url']}/{$dir2}/{$nameimage}'>
                        ";
                    }
                    ?>
                </div>

                <?php

                    global $BBCode_global;
                    global $HTMLCode_global;
                    global $DirectLink_global;
                    global $DirectLinkToImg_global;

                    $BBCode_global[] = "[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL]";
                    $HTMLCode_global[] = "<a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a>";
                    $DirectLink_global[] = "{$site_url}/img-{$view_id}.html";
                    $DirectLinkToImg_global[] = "{$rowFTP['url']}/{$dir2}/{$nameimage}";

                    echo "<div style='display:none;' class='ajax_BBCode'>[URL={$site_url}/img-{$view_id}.html][IMG]{$rowFTP['url']}/{$dirthumb2}/{$nameimage}[/IMG][/URL]</div>";
                    echo "<div style='display:none;' class='ajax_HTMLCode'><a href='{$site_url}/img-{$view_id}.html'><img src='{$rowFTP['url']}/{$dirthumb2}/{$nameimage}' alt='image' /></a></div>";
                    echo "<div style='display:none;' class='ajax_DirectLink'>{$site_url}/img-{$view_id}.html</div>";
                    echo "<div style='display:none;' class='ajax_DirectLinkToImg'>{$rowFTP['url']}/{$dir2}/{$nameimage}</div>";

                } else {
                    echo "<p class='error'>Sorry, there was a problem uploading your file.</p>";
                }


            } // END ELSE IF FTP IS NOT 0

        } // END ELSE IF OK IS OK OK OK :D 0 = OK
    } // END FUNCTION ZIP UPLOAD
} // END CLASS


class db{
    function connect(){
        $link = mysql_connect(DB_HOST, DB_USER, DB_PASS) or die("Couldn't make connection.");
        $db = mysql_select_db(DB_NAME, $link) or die("Couldn't select database");
        return $db;
    }

    function backup_tables($host,$user,$pass,$name,$tables = '*')
    {

        $link = mysql_connect($host,$user,$pass);
        mysql_select_db($name,$link);

        //get all of the tables
        if($tables == '*')
        {
            $tables = array();
            $result = mysql_query('SHOW TABLES');
            while($row = mysql_fetch_row($result))
            {
                $tables[] = $row[0];
            }
        }
        else
        {
            $tables = is_array($tables) ? $tables : explode(',',$tables);
        }

        //cycle through
        $return = "";
        foreach($tables as $table)
        {
            $result = mysql_query('SELECT * FROM '.$table);
            $num_fields = mysql_num_fields($result);


            $return.= 'DROP TABLE '.$table.';';
            $row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
            $return.= "\n\n".$row2[1].";\n\n";

            for ($i = 0; $i < $num_fields; $i++)
            {
                while($row = mysql_fetch_row($result))
                {
                    $return.= 'INSERT INTO '.$table.' VALUES(';
                    for($j=0; $j<$num_fields; $j++)
                    {
                        $row[$j] = addslashes($row[$j]);
                        $row[$j] = preg_replace("/\n/","\\n",$row[$j]);
                        if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
                        if ($j<($num_fields-1)) { $return.= ','; }
                    }
                    $return.= ");\n";
                }
            }
            $return.="\n\n\n";
        }

        //save file
        $handle = fopen('backup/db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql','w+');
        fwrite($handle,$return);
        fclose($handle);
    }
}

class galery {
    private function randomImages(){
        $q = "SELECT * FROM images ORDER BY RAND() LIMIT 20";
        $result = mysql_query($q);
        while($rowRandomGallery = mysql_fetch_assoc($result)) {

        }
    }
    function userGalleries(){
        $q = "SELECT * FROM galleries WHERE id_user = '$_SESSION[user_id]'";
        $result = mysql_query($q);
        if(mysql_num_rows($result) > 0) {
            echo "<table class='userGalleries' border=0>
            <tr>
            <td style='min-width:200px;'>Name</td>
            <td>Edit</td>
            </tr>";
            while($rowGalleries = mysql_fetch_assoc($result)) {
                echo "<tr><td><a class='nicelinks' href='view_galleries.php?id=".$rowGalleries['id']."'>" . $rowGalleries['name'] . "</a></td> <td><a class='nicelinks' href='edit_gallery.php?id=".$rowGalleries['id']."'><img src='css/img/modify.gif' /></a></td></tr>";
            }
            echo "</table>";
            } else {
                    echo "No galleries added yet ... ";
            }
    }

    function moreFromThisGallery($idgallery){
        global $site_url;
        if($idgallery > 0) {

        $q = "SELECT images.view_id, images.views, images.name, images.date_added, images.ftp, sources.thumb2, sources.img, ftp_logins.url FROM images
             INNER JOIN sources ON images.source=sources.id
             LEFT JOIN ftp_logins ON images.ftp = ftp_logins.id
             WHERE images.gallery = '{$idgallery}'
             ORDER BY RAND() LIMIT 24";
            $result = mysql_query($q);
        while($rowMoreFromThis = mysql_fetch_assoc($result)){
            if($rowMoreFromThis['ftp'] > 0) {
                $real_site_url = $rowMoreFromThis['url'];
            } else {
                $real_site_url = $site_url;
            }
            $dirDate = preg_replace('/-/', '/', $rowMoreFromThis['date_added']);
            $dirThumb = $real_site_url . "/" . $rowMoreFromThis['thumb2'] . "/" . $dirDate . "/" . $rowMoreFromThis['name'];
            //$dirImg = $site_url . "/" . $rowMoreFromThis['img'] . "/" . $dirDate . "/" . $rowMoreFromThis['name'];
            echo "<div class='more_from_this_gallery'>";
            echo "<a href='img-{$rowMoreFromThis['view_id']}.html'><img src='{$dirThumb}' /></a>";
            echo "</div>";
        }




        }
    }




}

class configs {
private $config = array();
private $rowConfigs = array();


    public function fetch() {
        $this->config = array();
        $q = "SELECT title, text FROM configs";
        $result = mysql_query($q);
        while($this->rowConfigs = mysql_fetch_assoc($result)) {
            $this->config[''.$this->rowConfigs['title'].''] = htmlspecialchars_decode($this->rowConfigs['text']);
        }
        return $this->config;
    }


    public function update($text, $id) {
        $text = mysql_real_escape_string($text);
        if(is_numeric($id)) {
        $q = "UPDATE configs SET text = '$text' WHERE id = '$id'";
        $result = mysql_query($q);
            if($result) {
                return true;
            }
        }
    }

    public function account_expired($exp_date){
    $todays_date = date("Y-m-d");

    $today = strtotime($todays_date);
    $expiration_date = strtotime($exp_date);

        if ($expiration_date > $today) {
            return true;
        } else {
            return false;
        }
    }

    function checkData($mydate) {

        list($yy,$mm,$dd)=explode("-",$mydate);
        if (is_numeric($yy) && is_numeric($mm) && is_numeric($dd))
        {
            return checkdate($mm,$dd,$yy);
        }
        return false;
    }

    public function isPremium($id_user){
        if(isset($id_user) && $id_user !== 0 && is_numeric($id_user)) {
                $q = "SELECT user_level, premium FROM users WHERE id = {$id_user}";
                $result = mysql_query($q);
                $rowUserPremium = mysql_fetch_assoc($result);

            if($this->account_expired($rowUserPremium['premium'])){
                return true;
            } else {
                return false;
            }

            }  else {
            return false;
        }
    }

    public function isLocked($id_user){
        if(isset($id_user) && $id_user !== 0 && is_numeric($id_user)) {

            $q = "SELECT locked FROM users WHERE id = {$id_user}";
            $result = mysql_query($q);
            $rowUserPremium = mysql_fetch_assoc($result);
            switch($rowUserPremium['locked']){
                case 0:
                    return false;
                    break;
                case 1:
                    return true;
                    break;
            }
        }  else {
            return false;
        }
    }





}

class pagination
{
    public function __construct()
    {
    }
    public function calculate_pages($total_rows, $rows_per_page, $page_num)
    {
        $arr = array();
        // calculate last page
        $last_page = ceil($total_rows / $rows_per_page);
        // make sure we are within limits
        $page_num = (int) $page_num;
        if ($page_num < 1)
        {
            $page_num = 1;
        }
        elseif ($page_num > $last_page)
        {
            $page_num = $last_page;
        }
        $upto = ($page_num - 1) * $rows_per_page;
        $arr['limit'] = 'LIMIT '.$upto.',' .$rows_per_page;
        $arr['current'] = $page_num;
        if ($page_num == 1)
            $arr['previous'] = $page_num;
        else
            $arr['previous'] = $page_num - 1;
        if ($page_num == $last_page)
            $arr['next'] = $last_page;
        else
            $arr['next'] = $page_num + 1;
        $arr['last'] = $last_page;
        $arr['info'] = 'Page ('.$page_num.' of '.$last_page.')';
        $arr['pages'] = $this->get_surrounding_pages($page_num, $last_page, $arr['next']);
        return $arr;
    }
    function get_surrounding_pages($page_num, $last_page, $next)
    {
        $arr = array();
        $show = 5; // how many boxes
        // at first
        if ($page_num == 1)
        {
            // case of 1 page only
            if ($next == $page_num) return array(1);
            for ($i = 0; $i < $show; $i++)
            {
                if ($i == $last_page) break;
                array_push($arr, $i + 1);
            }
            return $arr;
        }
        // at last
        if ($page_num == $last_page)
        {
            $start = $last_page - $show;
            if ($start < 1) $start = 0;
            for ($i = $start; $i < $last_page; $i++)
            {
                array_push($arr, $i + 1);
            }
            return $arr;
        }
        // at middle
        $start = $page_num - $show;
        if ($start < 1) $start = 0;
        for ($i = $start; $i < $page_num; $i++)
        {
            array_push($arr, $i + 1);
        }
        for ($i = ($page_num + 1); $i < ($page_num + $show); $i++)
        {
            if ($i == ($last_page + 1)) break;
            array_push($arr, $i);
        }
        return $arr;
    }
}

?>