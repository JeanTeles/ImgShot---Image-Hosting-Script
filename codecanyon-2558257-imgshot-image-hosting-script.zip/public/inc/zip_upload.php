<form id="uploadForm5" class="validateForm" name="uploadForm5" enctype="multipart/form-data" action="upload.php" method="post">
    <p style="font-size:13px; font-weight:bold;">Please choose a file:</p>
    <input class="fileadd required" id="uploadedzip" name="uploadedzip" type="file" />

    <div class="index_box">
        <input class="required" type="radio" name="adult" value="1" <?php if(ADULT_RADIOBOX == 1) {echo "checked = \"checked\"";} ?> /> Adult
        <input class="required" type="radio" name="adult" value="0" <?php if(ADULT_RADIOBOX == 0) {echo "checked = \"checked\"";} ?> />Non-Adult<br />
    </div>

    <br /> <br />
    <input class="cstranscustom" id="moreoptionszip" type="button" value="More Options" />
    <div id="hiddenzip">
        <div class="index_box">
            <select class="thumb_select" name="thumb_size_contaner">
                <option value="1"> <?php echo SMALL_THUMB . "x" . SMALL_THUMB; ?> (small thumbs) </option>
                <option value="2" selected="selected"> <?php echo MEDIUM_THUMB . "x" . MEDIUM_THUMB; ?> (standard thumbs) </option>
                <option value="3"> <?php echo LARGE_THUMB . "x" . LARGE_THUMB; ?> (large thumbs) </option>
                <option value="4"> <?php echo LARGER_THUMB . "x" . LARGER_THUMB; ?> (super-sized thumb) </option>
            </select>
        </div>

        <?php if(isset($gallery_selection)){ echo $gallery_selection; } ?>


        <p>Download Links:</p>
        <textarea name="download_links" rows="5" cols="50"></textarea>

    </div>
    <script type="text/javascript" >
        $('#moreoptionszip').click(function() {
            $('#hiddenzip').slideDown('slow', function() {
                // Animation complete.
            });
        });
    </script>

    <!--[if IE]>
    <div class="upload_now">
        <input type="submit" name="zip_upload" value="Upload" />
    </div>
    <![endif]-->

    <!--[if !IE]> -->
    <br />
    <input class="upload" style="width:200px; height:40px; margin-top:20px;" type="submit" name="zip_upload" value="Upload" />
    <!-- <![endif]-->
</form>