<div id="footer">
    <p> <a href="page-DMCA.html">[DMCA]</a> &nbsp; <a href="page-DMCA.html">[REPORT ABUSE]</a> </p>
    Copyright &copy; <?php echo date('Y'); ?> - All Rights Reserved <br />
    Version: <?php echo $site_version; ?>
</div>
