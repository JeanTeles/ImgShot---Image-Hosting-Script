<div id="content_menu">
    <div id="menu_links">
        <ul>
            <li><a href="myaccount.php"><img border="0" style="position:absolute; margin-top:-5px;" src="css/img/home.png" alt="H" /><span class="invisible">Home</span></a></li>
            <li><a href="mysettings.php">My Settings</a></li>
            <li><a href="my_images.php">Images</a></li>
            <li><a href="moderate_img.php">Search & Moderate</a></li>
            <li><a href="galleries.php">Galleries</a></li>
            <li><a href="support.php">Support</a></li>
            <li><a href="pm.php?page=inbox">PM</a></li>
            <li><a href="accupgrade.php">Upgrade</a></li>
        </ul>
    </div>
</div>