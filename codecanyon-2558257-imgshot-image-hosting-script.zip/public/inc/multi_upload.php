<form id="uploadForm2" class="validateForm" name="uploadForm2" enctype="multipart/form-data" action="upload.php" method="post">
    <p style="font-size:13px; font-weight:bold;">Please choose a file:</p>
    <input class="fileadd required" id="uploaded1" name="uploaded" type="file" />
    <input class="fileadd" id="uploaded2" name="uploaded2" type="file" />
    <input class="fileadd" id="uploaded3" name="uploaded3" type="file" />
    <input class="fileadd" id="uploaded4" name="uploaded4" type="file" />
    <input class="fileadd" id="uploaded5" name="uploaded5" type="file" />
    <input class="fileadd" id="uploaded6" name="uploaded6" type="file" />
    <input class="fileadd" id="uploaded7" name="uploaded7" type="file" />
    <input class="fileadd" id="uploaded8" name="uploaded8" type="file" />
    <input class="fileadd" id="uploaded9" name="uploaded9" type="file" />
    <input class="fileadd" id="uploaded10" name="uploaded10" type="file" />

    <div class="index_box">
        <input class="required" type="radio" name="adult" value="1" <?php if(ADULT_RADIOBOX == 1) {echo "checked = \"checked\"";} ?> /> Adult
        <input class="required" type="radio" name="adult" value="0" <?php if(ADULT_RADIOBOX == 0) {echo "checked = \"checked\"";} ?> />Non-Adult<br />
    </div>

    <br /><br />
    <input class="cstranscustom" id="moreoptions_multiupload" type="button" value="More Options" />
    <div id="hidden_multiupload">
        <div class="index_box">
            <select class="thumb_select" name="thumb_size_contaner">
                <option value="1"> <?php echo SMALL_THUMB . "x" . SMALL_THUMB; ?> (small thumbs) </option>
                <option value="2" selected="selected"> <?php echo MEDIUM_THUMB . "x" . MEDIUM_THUMB; ?> (standard thumbs) </option>
                <option value="3"> <?php echo LARGE_THUMB . "x" . LARGE_THUMB; ?> (large thumbs) </option>
                <option value="4"> <?php echo LARGER_THUMB . "x" . LARGER_THUMB; ?> (super-sized thumb) </option>
            </select>
        </div>

        <?php if(isset($gallery_selection)){ echo $gallery_selection; } ?>

        <p>Download Links:</p>
        <textarea name="download_links" rows="5" cols="50"></textarea>

    </div>
    <script type="text/javascript">
        $('#moreoptions_multiupload').click(function() {
            $('#hidden_multiupload').slideDown('slow', function() {
                // Animation complete.
            });
        });
    </script>


    <!--[if IE]>
    <div class="upload_now">
        <input type="submit" name="multi_upload" value="Upload" />
    </div>
    <![endif]-->

    <!--[if !IE]> -->
    <br />
    <input class="upload" style="width:200px; height:40px; margin-top:20px;" type="submit" name="multi_upload" value="Upload" />
    <!-- <![endif]-->

</form>