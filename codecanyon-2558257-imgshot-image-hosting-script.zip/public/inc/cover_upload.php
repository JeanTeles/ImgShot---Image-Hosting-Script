<form id="uploadForm4" class="validateForm" name="uploadForm" enctype="multipart/form-data" action="upload.php" method="post">
    <p style="font-size:13px; font-weight:bold;">Please choose a file:</p>
    <input class="fileadd required" id="uploadedCover" name="uploaded" type="file" />
    <div class="index_box">
        <input class="required" type="radio" name="adult" value="1" <?php if(ADULT_RADIOBOX == 1) {echo "checked = \"checked\"";} ?> /> Adult
        <input class="required" type="radio" name="adult" value="0" <?php if(ADULT_RADIOBOX == 0) {echo "checked = \"checked\"";} ?> />Non-Adult<br />
        <input type="hidden" value="5" name="thumb_size_contaner" />
    </div>
    <br /> <br />
    <input class="cstranscustom" id="moreoptions_coverupload" type="button" value="More Options" />
    <div id="hidden_coverupload">
        <?php if(isset($gallery_selection)){ echo $gallery_selection; } ?>

        <p>Download Links:</p>
        <textarea name="download_links" rows="5" cols="50"></textarea>

    </div>
    <script type="text/javascript">
        $('#moreoptions_coverupload').click(function() {
            $('#hidden_coverupload').slideDown('slow', function() {
                // Animation complete.
            });
        });
    </script>

    <!--[if IE]>
    <div class="upload_now">
        <input type="submit" name="simple_upload" value="Upload" />
    </div>
    <![endif]-->

    <!--[if !IE]> -->
    <br />
    <input class="upload" style="width:200px; height:40px; margin-top:20px;" type="submit" name="simple_upload" value="Upload" />
    <!-- <![endif]-->

</form>