<?php
if($_SERVER['REQUEST_METHOD'] != 'POST') {
?>
<form method="post" class="contactForm" name="contactForm" action="">
    <table>
        <tr>
            <td class="first">Name: </td>
            <td><input type="text" size="35" name="cName" id="cName" /></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td><input type="text" size="35" name="cEmail" id="cEmail" /></td>
        </tr>
        <tr>
            <td>Message:</td>
            <td><textarea id="message" name="message" rows="8" cols="50"></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td><?php
                require_once('recaptchalib.php');
                echo recaptcha_get_html($publickey);
                ?></td>
        </tr>
        <tr>
            <td></td>
            <td><input class="button white smaller" type="submit" value="Submit" /> <input class="button white smaller" type="reset" value="Reset" /></td>
        </tr>
    </table>
</form>
<?php
}
else
{

    /********************* RECAPTCHA CHECK *******************************
    This code checks and validates recaptcha
     ****************************************************************/
    require_once('recaptchalib.php');

    $resp = recaptcha_check_answer ($privatekey,
        $_SERVER["REMOTE_ADDR"],
        $_POST["recaptcha_challenge_field"],
        $_POST["recaptcha_response_field"]);

    if (!$resp->is_valid) {
        echo ("<p class='error'>Image Verification failed! Go back and try again.</p>" .
            "<p class='error'>reCAPTCHA said: " . $resp->error . "</p>");
    } else {


    $cname = trim(stripslashes(strip_tags($_POST['cName'])));
    $cemail = trim(stripslashes(strip_tags($_POST['cEmail'])));
    $cmessage = trim(stripslashes(strip_tags($_POST['message'])));

    $emailTo = ADMIN_EMAIL;
    $subject = "Contact Request Sent via Website";


    $message = "From: $cname, Email: $cemail<br /><hr />$cmessage";

    sendMail($emailTo, "Admin", $subject, $message);

    echo "<p class='success'>Thank you for contacting our Enquiries Department. Your request will be attended to shortly</p>";
    }
}
?>