<?php if(UPLOAD_ONLY_REGISTERED == 0 || isset($_SESSION['user_id'])) { ?>
<div style='display:none;' class="ui-progressbar ui-widget ui-widget-content ui-corner-all" id="progressbarOver">
    <div style="width: 0%; height:20px;" class="ui-progressbar-value ui-widget-header ui-corner-left" id="progressbar"></div>
</div>

<br />

<input id="file_upload" type="file" name="file_upload" />
<br />


<div class="index_box">
    <a href="index.php?adult=0#tabs-3" class="button white" ><span>Clean</span></a>
    <a href="index.php?adult=1#tabs-3" class="button white" ><span>Adult</span></a>
</div>



<?php } ?>
    

<br />
    <div style='display:none;' id="ajax_allbbcodes">
All BB Codes:<br />
<textarea onclick="this.select();" class='ajaxbbcodes' id="ajax_bbcodes" rows="5" cols="50"></textarea><br /><br />
All HTML Codes:<br />
<textarea onclick="this.select();" class='ajaxbbcodes' id="ajax_HTMLcodes" rows="5" cols="50"></textarea><br /><br />
All Direct Links:<br />
<textarea onclick="this.select();" class='ajaxbbcodes' id="ajax_DirectLinks" rows="5" cols="50"></textarea><br /><br />
        <?php if(DIRECT_LINK_SHOW == 1) { ?>
            All Direct Links to Images:<br />
            <textarea onclick="this.select();" class='ajaxbbcodes' id="ajax_DirectLinkToImgs" rows="5" cols="50"></textarea><br /><br />
        <?php } ?>
    </div>

<div id="testajax"></div>





