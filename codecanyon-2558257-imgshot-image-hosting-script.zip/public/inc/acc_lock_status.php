<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


if(isset($lockedStatus)) {

    echo "<div class='account_lock'>";
    if($lockedStatus){
        echo "
        <a href='lock_unlock_account.php'><img border='0' src='css/img/acc_locked.png' /></a>
        <p>Account Locked</p>
        ";
    } else {
        echo "
        <a href='lock_unlock_account.php'><img border='0' src='css/img/acc_unlocked.png' /></a>
        <p>Account Unlocked</p>
        ";
    }
    echo "</div>";

}
?>