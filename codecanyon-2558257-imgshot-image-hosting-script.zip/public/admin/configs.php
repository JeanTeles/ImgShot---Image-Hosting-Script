<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();

$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

foreach($_POST as $key => $value) {
    $data[$key] = filter($value);
}
$configs = new configs();

if(isset($_POST['updateconfig'])) {
    $configs->update($_POST['analytics'], '1');
    $configs->update($_POST['clean_top_ads'], '2');
    $configs->update($_POST['clean_bottom_ads'], '3');
    $configs->update($_POST['adult_top_ads'], '4');
    $configs->update($_POST['adult_bottom_ads'], '5');
    $configs->update($_POST['premium_ads_top'], '6');
    $configs->update($_POST['premium_ads_bottom'], '7');
    $configs->update($_POST['popup_clean'], '8');
    $configs->update($_POST['popup_adult'], '9');
    $configs->update($_POST['share_plugins'], '10');
}


$configs = $configs->fetch();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/csTransPie.css" />
    <link type="text/css" href="../css/smoothness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.18.custom.min.js"></script>
    <script type="text/javascript" src="../js/csTransPie.js"></script>
    <script type="text/javascript">
        $(function() {
            $( "#accordion" ).accordion({ autoHeight: false });
            $( "input:submit, a, button", ".updatecfg" ).button();
        });
    </script>



</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content">

            <form action="" method="POST">
                <div id='accordion'>
                    <h3><a href='#'>Analytics (google or whatever):</a></h3><div>
                <p>
                    <textarea class="large" name="analytics"><?php echo stripslashes(htmlspecialchars($configs['analytics'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Clean Ads - Top:</a></h3><div>
                <p>
                    <textarea class="large" name="clean_top_ads"><?php echo stripslashes(htmlspecialchars($configs['clean_top_ads'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Clean Ads - Bottom:</a></h3><div>
                <p>
                    <textarea class="large" name="clean_bottom_ads"><?php echo stripslashes(htmlspecialchars($configs['clean_bottom_ads'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Clean side pop-up:</a></h3><div>
                <p>
                    <textarea class="large" name="popup_clean"><?php echo stripslashes(htmlspecialchars($configs['popup_clean'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Adult Ads - Top:</a></h3><div>
                <p>
                    <textarea class="large" name="adult_top_ads"><?php echo stripslashes(htmlspecialchars($configs['adult_top_ads'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Adult Ads - Bottom:</a></h3><div>
                <p>
                    <textarea class="large" name="adult_bottom_ads"><?php echo stripslashes(htmlspecialchars($configs['adult_bottom_ads'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Adult side pop-up:</a></h3><div>
                <p>
                    <textarea class="large" name="popup_adult"><?php echo stripslashes(htmlspecialchars($configs['popup_adult'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Premium User Ads - Top:</a></h3><div>
                <p>
                    <textarea class="large" name="premium_ads_top"><?php echo stripslashes(htmlspecialchars($configs['premium_ads_top'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Premium User Ads - Bottom:</a></h3><div>
                <p>
                    <textarea class="large" name="premium_ads_bottom"><?php echo stripslashes(htmlspecialchars($configs['premium_ads_bottom'])); ?></textarea>
                </p>
                    </div>
                    <h3><a href='#'>Share plugins:</a></h3><div>
                    <p>
                        <textarea class="large" name="share_plugins"><?php echo stripslashes(htmlspecialchars($configs['share_plugins'])); ?></textarea>
                    </p>
                </div>

                    </div>

            <p>
                <input type="submit" class="updatecfg" name="updateconfig" value="Update" />
            </p>
            </form>
        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>