<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/
require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();
$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
}
$configs = new configs();

if(isset($_POST['search_by_username']) && ctype_alnum($_POST['search_by_username'])){
    $username = filter($_POST['search_by_username']);
    $q = "SELECT id FROM users WHERE user_name LIKE '$username%'";
    $result = mysql_query($q);
    if($result && mysql_num_rows($result) > 0) {
        $row_search_id = mysql_fetch_assoc($result);
        header('Location: users.php?id='.$row_search_id['id'].'');
        exit();
    }
} elseif(isset($_POST['search_by_picture']) && ctype_alnum($_POST['search_by_picture'])){
    $pictureid = filter($_POST['search_by_picture']);
    $q = "SELECT id_user FROM images WHERE view_id LIKE '$pictureid%'";
    $result = mysql_query($q);
    if($result && mysql_num_rows($result) > 0) {
        $row_search_id = mysql_fetch_assoc($result);
        header('Location: users.php?id='.$row_search_id['id_user'].'');
        exit();
    }
}

if(isset($_GET['id'])){
    if(is_numeric($_GET['id'])) {
        $id = $_GET['id'];

        if(isset($_POST['expireset'])) {
            if($configs->checkData($_POST['expireset'])) {
                mysql_query("UPDATE users SET `premium` = '{$_POST['expireset']}' WHERE `id` = '$id'");
            }
        }


    } else {
        header('Location: index.php');
        exit();
    }
}


if(isset($_POST['changeUser']) && isset($id)){
    foreach($_POST as $key => $value) {
        $data[$key] = filter($value);
    }

    $q = "UPDATE users SET full_name = '{$data['full_name']}', user_email = '{$data['user_email']}', user_level = '{$data['user_level']}', approved = '{$data['approved']}' WHERE id = {$id}";
    $result = mysql_query($q);
    if($result) {
        $editUserSucces = true;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/grid.css" />
    <link rel="stylesheet" type="text/css" href="../css/csTransPie.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.18.custom.min.js"></script>
    <link type="text/css" href="../css/smoothness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
    <script type="text/javascript" src="../js/csTransPie.js"></script>
    <script type="text/javascript">
        $(function() {
            $( ".rightbutton" ).button();
        });
    </script>

    <script type="text/javascript">
        $(function() {
            $( "#expireset" ).datepicker({dateFormat: "yy-mm-dd"});
        });
    </script>

</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content" class="container_12">

            <?php
            if(isset($editUserSucces)) {
            echo "<p class='success'>You have succesfuly edited user</p>";
            }

            if(isset($id)) {
                $q = "SELECT * FROM users WHERE id = {$id}";
                $result = mysql_query($q);
                if(mysql_num_rows($result) > 0){
                    
                
                $rowUser = mysql_fetch_assoc($result);


                    
                    echo "
                    <div class='grid_9'>
                    <h2>Edit user: {$rowUser['user_name']}</h2> <hr>
                    <p><strong>Date registered:</strong> {$rowUser['date']}</p>
                    
                    <form action='' method='POST'>
                    <p><strong>Name:</strong> <br />
                    <input type='text' name='full_name' value='{$rowUser['full_name']}' />
                    </p>
                    
                    <p><strong>Email:</strong> <br />
                    <input type='text' name='user_email' value='{$rowUser['user_email']}' />
                    </p>
                    
                    ";


                    ?>
                <p><strong>User Level:</strong> <br /> <br />
                    <input type='radio' name='user_level' <?php if($rowUser['user_level'] == 1) { echo "checked = 'checked'"; } ?> value= '1' /> Normal User
                    <input type='radio' name='user_level' <?php if($rowUser['user_level'] == 5) { echo "checked = 'checked'"; } ?> value= '5' /> Administrator
                </p>

                <p><strong>Approved:</strong> <br /><br />
                <input type='radio' name='approved' <?php if($rowUser['approved'] == 1) { echo "checked = 'checked'"; } ?> value= '1' /> Yes
                <input type='radio' name='approved' <?php if($rowUser['approved'] == 0) { echo "checked = 'checked'"; } ?> value= '0' /> No
                </p>

                <p><input class='lock_button' type='submit' value='Make changes' name='changeUser' /></p>
                </form>
                    
                </div>
                    <div class="grid_3">
                        <a class='button gray big mediumwidth2'  href='all_images.php?id_user=<?php echo $rowUser['id']; ?>'><span>View all user's images</span></a>
                        <a class='button gray big mediumwidth2'  href='ipn_transactions.php?id=<?php echo $rowUser['id']; ?>'><span>View all IPN transactions</span></a>
                    <br />
                        <?php
                        if($configs->account_expired($rowUser['premium'])) {
                            echo "<a class='button blue big mediumwidth2'><span>Premium User  [ {$rowUser['premium']} ]</span></a>";
                        } else {
                            echo "<a class='button green big mediumwidth2'><span>Regular User</span></a>";
                        } ?>
                        <form action="" method="POST">
                            <p>Make premium till: <br />
                                <input type="text" name="expireset" id="expireset" /></p>
                            <p><input class="button white medium" type="submit" name="expiresetsubmit" value="Update"</p>
                        </form>

                    </div>
                    <div class="clear">&nbsp;</div>
                <?php
                } else {
                    echo "<p class='error'>No user found matching your search criteria ... </p>";
                }
                
                


            } else {
                echo "<div class='grid_9'>";
                echo "
                <h2>Search by name:</h2>
                <form action='' method='POST'>
                <input type='text' name='search_by_username' />
                <input type='submit' />
                </form>
<hr>
                <form action='' method='POST'>
                <h2>Search by picture id:</h2>
                <input type='text' name='search_by_picture' />
                <input type='submit' />
                </form>
                ";
echo "<hr> <br />";

                echo "<h2>Latest 20 registered users</h2>";
            $q = "SELECT id, user_name FROM users ORDER BY id DESC LIMIT 20";
            $result = mysql_query($q);
            if($result) {
                echo "
            <div id='users-contain' class='ui-widget'>
            <table class='ui-widget ui-widget-content' border='0'>
                <thead>
                    <tr class='ui-widget-header'>
                    <td>Name</td>
                    <td style='width:10px;'>Edit</td>
                    </tr>
                </thead><tbody>";
                while($rowUsers = mysql_fetch_assoc($result)) {
                    echo "<tr><td><a class='nicelinks' href='users.php?id={$rowUsers['id']}'>" . $rowUsers['user_name'] . "</a></td> <td><a href='users.php?id=".$rowUsers['id']."'><img border='0' src='../css/img/modify.gif' /></a></td></tr>";
                }
                echo "</tbody></table></div>";
            }

            ?>


        </div>
        <div class="grid_3">
            <a href='banning.php' class="button blue medium mediumwidth2"><span>User Banning</span></a>
            <a href='ipn_transactions.php' class="button blue medium mediumwidth2"><span>IPN Transactions</span></a>
        </div>
        <div class="clear"></div>
<?php } ?>
        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>