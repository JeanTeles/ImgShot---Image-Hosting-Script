<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

if(isset($_POST['empty_table'])){
    $q = "TRUNCATE TABLE badpass";
    $result = mysql_query($q);
    if($result){
        $sqlSucces = true;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.18.custom.min.js"></script>
    <link type="text/css" href="../css/smoothness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
    <script>
        $(function() {
            $( "input:submit, a, button", ".empty_table_form" ).button();
        });
    </script>


</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content">
            <?php
            if(isset($sqlSucces)){
                echo "<p class='success'>Logs empty succesfuly !</p>";
            }
        ?>

            <?php
            $q = "SELECT * FROM badpass ORDER by ID desc";
            $result = mysql_query($q);

            if($result){
                if(mysql_num_rows($result) > 0) {
            ?>
            <table class="badpasslogs">
                <tbody>
                <tr>
                    <th>IP</th>
                    <th>Users Entered</th>
                    <th>Times</th>
                    <th>Date</th>
                </tr>
            <?php
                while($rowBadpassLogs = mysql_fetch_assoc($result)){
                    echo "
                    <tr>
                    <td>{$rowBadpassLogs['ip']}</td>
                    <td>{$rowBadpassLogs['user']}</td>
                    <td>{$rowBadpassLogs['times']}</td>
                    <td>{$rowBadpassLogs['date']}</td>
                    </tr>
                    ";
                }
            ?>
                </tbody>
            </table>

            <?php
                } else {
                    echo "<p class='error'>There are no logs at this moment ... </p>";
                }
            }
            ?>

        <div style='text-align:center;' class="empty_table_form">
            <form style='margin-top:40px;' action="" method="POST">
                <input type="submit" name="empty_table" value="Clear Logs" />
            </form>
        </div>
        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>