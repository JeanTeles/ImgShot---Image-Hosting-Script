<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];


    if(isset($_POST['page'])) {
        $content = addslashes($_POST['page']);
        $q = "UPDATE pages SET content = '$content' WHERE id = $id";
        $result = mysql_query($q);
        if($result) {
            $mysql_update_succes = true;
        } else {
            echo mysql_error();
        }
    }



    $q = "SELECT * FROM pages WHERE id = '$id'";
    $result = mysql_query($q);
    if(mysql_num_rows($result) > 0) {
        $rowPage = mysql_fetch_assoc($result);
    } else {
        header('Location: pages.php');
        exit();
    }









}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/smoothness/jquery-ui-1.8.18.custom.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.18.custom.min.js"></script>
    <script type="text/javascript" src="../js/tiny_mce/tiny_mce.js"></script>
    <script type="text/javascript">
        tinyMCE.init({
            mode : "exact",
            elements : "page",
            theme : "advanced",
            plugins : "autolink,lists,spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

            // Theme options - button# indicated the row# only
            theme_advanced_buttons1 : "newdocument,|,bold,italic,underline,|,justifyleft,justifycenter,justifyright,justifyfull,fontselect,fontsizeselect,formatselect",
            theme_advanced_buttons2 : "cut,copy,paste,|,bullist,numlist,|,outdent,indent,|,undo,redo,|,link,unlink,anchor,image,|,code,preview,|,forecolor,backcolor",
            theme_advanced_buttons3 : "insertdate,inserttime,|,spellchecker,advhr,,removeformat,|,sub,sup,|,charmap,emotions",
            theme_advanced_toolbar_location : "top",
            theme_advanced_toolbar_align : "left",
            theme_advanced_statusbar_location : "bottom",
            theme_advanced_resizing : true
        });
    </script>

    <script type="text/javascript">
        $(function() {
            $( ".buttonlinks" ).button();
        });
    </script>


</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        
        <div id="content">
            
            <?php
            if(isset($mysql_update_succes)) {
                echo "<p class='success'>You have succesfuly updated <strong>{$rowPage['title']}</strong> page</p>";
            }
            
            if(isset($id)) {
                echo "<h3>You are editing page: <strong>{$rowPage['title']}</strong></h3> <hr> <br />";
            ?>

            <form method="POST" action="">
                <textarea id="page" name="page" cols="80" rows="35"><?php echo stripslashes($rowPage['content']); ?></textarea>
                <input class="buttonlinks" style="margin-top:20px; width:100px; height:30px; font-size:17px;" value="Update" type="submit" />
            </form>
                <br />
                
            <?php } else { 
                
                $q = "SELECT * FROM pages";
                $result = mysql_query($q);
                while($rowPages = mysql_fetch_assoc($result)) {
                    echo "<a class='buttonlinks' href=\"pages.php?id={$rowPages['id']}\">{$rowPages['title']}</a> <br />";
                }
                
            }
          ?>
                
        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>