<?php
require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

$dirSql = filter($_GET['sql']);

if (file_exists($dirSql)) {
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename='.basename($dirSql));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($dirSql));
ob_clean();
flush();
readfile($dirSql);
exit;
}



?>