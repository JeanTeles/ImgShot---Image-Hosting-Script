<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

if(isset($_POST['add_ban_user'])) {
    $add_ban_user = filter($_POST['add_ban_user']);
    $add_ban_user_reason = filter($_POST['reason_user']);
    $q = "SELECT id FROM users WHERE user_name LIKE '$add_ban_user'";
    $result = mysql_query($q);
    if($result && mysql_num_rows($result) > 0) {
        $rowUsers = mysql_fetch_assoc($result);
        mysql_query("INSERT INTO banned_users (`id_user`,`reason`) VALUES ('{$rowUsers['id']}', '$add_ban_user_reason')");
    }
}

if(isset($_POST['add_ban_ip'])) {
    $add_ban_ip = filter($_POST['add_ban_ip']);
    $add_ban_ip_reason = filter($_POST['reason_ip']);
        mysql_query("INSERT INTO banned_ip (`ip`,`reason`) VALUES ('$add_ban_ip', '$add_ban_ip_reason')");
}


if(isset($_POST['remove_ban_ip'])){
    $remove_ban_ip = $_POST['remove_ban_ip'];
    $q = "SELECT id FROM banned_ip WHERE ip LIKE '$remove_ban_ip'";
    $result = mysql_query($q);
        if($result && mysql_num_rows($result) > 0) {
            mysql_query("DELETE FROM banned_ip WHERE IP like '$remove_ban_ip'");
        }
}

if(isset($_POST['remove_ban_user'])) {
    $remove_ban_user = filter($_POST['remove_ban_user']);
    $q = "SELECT id FROM users WHERE user_name LIKE '$remove_ban_user'";
    $result = mysql_query($q);
    if($result && mysql_num_rows($result) > 0) {
        $rowUsers = mysql_fetch_assoc($result);
        mysql_query("DELETE FROM banned_users WHERE id_user = '{$rowUsers['id']}'");
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/csTransPie.css" />
    <link rel="stylesheet" type="text/css" href="../css/grid.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/csTransPie.js"></script>

</head>
<body>
<?php include("inc/menu.php"); ?>


<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content" class="container_12">
        <div class="grid_12">
            <h2>Banned IP/Users</h2>
            <hr>
        </div>
            <div class="clear">&nbsp;</div>

            <div class="grid_6">
                <form action="" method="POST">
                    <h2>User banning</h2>
                    <p>
                        Ban user: <br />
                        <input type="text" name="add_ban_user" />
                        <input type="text" name="reason_user" value='no reason' />
                        <input type="submit" />
                    </p>
                </form>

                    <form action="" method="POST">

                    <p>
                        Remove user ban: <br />
                        <input type="text" name="remove_ban_user" />
                        <input type="submit" />
                    </p>


                </form>
            </div>
            <div class="grid_6">
                <form action="" method="POST">
                    <h2>IP banning</h2>

                    <p>
                        Ban IP: <br />
                        <input type="text" name="add_ban_ip" />
                        <input type="text" name="reason_ip" value='no reason' />
                        <input type="submit" />
                    </p>
                </form>

                <form action="" method="POST">
                    <p>
                        Remove ip ban: <br />
                        <input type="text" name="remove_ban_ip" />
                        <input type="submit" />
                    </p>
                </form>

            </div>
            <div class="clear">&nbsp;</div>
<hr>
            <div class="grid_6">
                <h2>Banned Users</h2>
                <textarea cols="40" rows="20"><?php
                $q = "SELECT banned_users.reason, users.user_name FROM banned_users
                 INNER JOIN users ON banned_users.id_user = users.id
                 ORDER BY banned_users.id DESC
                 ";
                $result = mysql_query($q);
                while($rowBannedUsers = mysql_fetch_assoc($result)) {
                    echo $rowBannedUsers['user_name'] . " - " . $rowBannedUsers['reason'] . "\r\n";
                }
                ?></textarea>
            </div>
            <div class="grid_6">
                <h2>Banned Ip's</h2>
                <textarea cols="40" rows="20"><?php
                    $q = "SELECT banned_ip.reason, banned_ip.ip FROM banned_ip ORDER BY id DESC
                 ";
                    $result = mysql_query($q);
                    while($rowBannedIp = mysql_fetch_assoc($result)) {
                        echo $rowBannedIp['ip'] . " - " . $rowBannedIp['reason'] . "\r\n";
                    }
                    ?></textarea>
            </div>
            <div class="clear">&nbsp;</div>
        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>