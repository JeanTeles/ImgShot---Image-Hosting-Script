<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.18.custom.min.js"></script>
    <link type="text/css" href="../css/smoothness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />

    <script type="text/javascript">
        $(function() {
            $( "input:submit, a, button", ".links,.cool_design" ).button();
            $( "#check" ).button();
            $( "#removeall" ).button();
        });
    </script>

</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content">



            <?php
            if(isset($_POST['date_last_view']) && is_numeric($_POST['day']) && is_numeric($_POST['month']) && is_numeric($_POST['year'])){
                $day = $_POST['day'];
                $month = $_POST['month'];
                $year = $_POST['year'];
                $last_date = $year . "-" . $month . "-" . $day;
                $q = "SELECT images.id, images.name, images.date_added, images.view_id, images.ftp, sources.thumb2, sources.img2, sources.thumb, sources.img, ftp_logins.url, ftp_logins.host, ftp_logins.user, ftp_logins.pass FROM images
                INNER JOIN sources ON images.source=sources.id
                LEFT JOIN ftp_logins ON images.ftp = ftp_logins.id
                WHERE images.last_view <= '{$last_date}'";
                $result = mysql_query($q);
                if($result){
                    $numRows = mysql_num_rows($result);
                    echo "<p style='font-size:15px;'>Found <strong>{$numRows}</strong> images older than {$last_date}</p>";
                    while($rowImages = mysql_fetch_assoc($result)) {
                        if($rowImages['ftp'] > 0) {
                            $real_site_url = $rowImages['url'];
                        } else {
                            $real_site_url = $site_url;
                        }

                        $dirDate = preg_replace('/-/', '/', $rowImages['date_added']);
                        $dirThumb = $real_site_url . "/" . $rowImages['thumb'] . "/" . $dirDate . "/" . $rowImages['name'];

                        if(isset($_POST['remove_all']) && isset($_POST['confirm_remove_all']) && $rowImages['ftp'] == 0){
                            mysql_query("DELETE FROM images WHERE id ='".$rowImages['id']."'");
                            $imgUnlink = "../" . $rowImages['img2'] . "/" . $dirDate . "/" . $rowImages['name'];
                            $thumbUnlink = "../" . $rowImages['thumb2'] . "/" . $dirDate . "/" . $rowImages['name'];
                            while(is_file($imgUnlink) == TRUE) {
                                chmod($imgUnlink, 0666);
                                unlink($imgUnlink);
                            }
                            while(is_file($thumbUnlink) == TRUE) {
                                chmod($thumbUnlink, 0666);
                                unlink($thumbUnlink);
                            }
                        } elseif(isset($_POST['remove_all']) && isset($_POST['confirm_remove_all']) && $rowImages['ftp'] > 0) {
                            $imgUnlink = $rowImages['img'] . "/" . $dirDate . "/" . $rowImages['name'];
                            $thumbUnlink =  $rowImages['thumb'] . "/" . $dirDate . "/" . $rowImages['name'];
                            mysql_query("DELETE FROM images WHERE view_id ='".$rowImages['view_id']."'");

                            $FTP = new FTP();
                            global $ftp_conn_id;
                            $FTP->connect($rowImages['host'], $rowImages['user'], $rowImages['pass']);
                            ftp_delete($ftp_conn_id, $imgUnlink);
                            ftp_delete($ftp_conn_id, $thumbUnlink);
                            $FTP->disconnect($ftp_conn_id);
                        }

                        echo "<a href='../img-{$rowImages['view_id']}.html' target='_blank'>" . $rowImages['name'] . "</a>, ";

                    }
                    echo "
                    <br />
                    <form action='' method='POST'>
                        <p>
                        <input type='checkbox' name='confirm_remove_all' id='check' /><label style='width:300px;' for='check'>I confirm that i want to remove all</label>
                        <input type='submit' name='remove_all' value='REMOVE ALL' id='removeall' />
                        <input type='hidden' name='date_last_view' value='' />
                        <input type='hidden' name='day' value='{$day}' />
                        <input type='hidden' name='month' value='{$month}' />
                        <input type='hidden' name='year' value='{$year}' />
                        </p>
                    </form>
                    ";
                } else {
                    die(mysql_error());
                }



            } else {
?>

                <div id="admin_user_right_box" class="links">
                    <a href='badpass_logs.php'>View Bad Passwords Logs</a>
                    <a href='bkupsql.php'>Back-up Database</a>
                    <a href='update'>Update Script</a>
                </div>


<p style='font-size:16px; font-weight:bold;'>Find all images with no view since :</p>
<form action="" method="POST">
<table>
    <tbody>
            <tr>
                <td>
                    <strong>Day:</strong>
                    <select name="day" id="day" onchange="" size="1">
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option>
                    </select>
                    <strong>Month:</strong>
                    <select name="month" id="month" onchange="" size="1">
                        <option value="01">January</option>
                        <option value="02">February</option>
                        <option value="03">March</option>
                        <option value="04">April</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">August</option>
                        <option value="09">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                    <strong>Year:</strong>
                    <select name="year" id="year" onchange="" size="1">
                        <option value="2009">2009</option>
                        <option value="2010">2010</option>
                        <option value="2011">2011</option>
                        <option value="2012">2012</option>
                        <option value="2013">2013</option>
                    </select>
                </td>
                <td><div class="cool_design"><input type="submit" name="date_last_view" /></div></td>
            </tr>
    </tbody>
</table>
</form>

    <?php } ?>

        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>