<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

if(isset($_POST['update_server']) && isset($_GET['id']) && is_numeric($_GET['id']) && isset($_POST['source_id']) && is_numeric($_POST['source_id'])) {
    $q = "UPDATE ftp_logins SET `url` = '{$_POST['url']}', `host` = '{$_POST['host']}', `user` = '{$_POST['user']}', `pass` = '{$_POST['pass']}', `active` = '{$_POST['active']}' WHERE id = {$_GET['id']}";
    $result = mysql_query($q);
    $q2 = "UPDATE sources SET img = '{$_POST['full_ftp_img_patch']}', thumb = '{$_POST['full_ftp_thumb_patch']}', img2 = '{$_POST['img_patch']}', thumb2 = '{$_POST['thumb_patch']}' WHERE id = {$_POST['source_id']}";
    $result2 = mysql_query($q2);
    if($result && $result2){
        $update_succes = true;
    }
}

if(isset($_POST['confirm_delete_server']) && isset($_POST['delete_server']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $q = "DELETE FROM ftp_logins WHERE id = {$_GET['id']} LIMIT 1";
    $result = mysql_query($q);
    if($result) {
        header('Location: multi_server.php?msg=You have succesfuly removed specific server !');
        exit();
    } else {
        echo mysql_error();
    }
}

if(isset($_POST['add_new_server'])) {
    $q = "INSERT INTO sources (`img`,`thumb`,`img2`,`thumb2`) VALUES ('{$_POST['full_ftp_img_patch']}','{$_POST['full_ftp_thumb_patch']}','{$_POST['img_patch']}','{$_POST['thumb_patch']}')";
    $result = mysql_query($q);
    if($result) {
    $source_id_sql = mysql_insert_id();

    $q2 = "INSERT INTO ftp_logins (`url`, `host`, `user`, `pass`, `source_id`) VALUES ('{$_POST['url']}','{$_POST['host']}','{$_POST['user']}','{$_POST['pass']}','$source_id_sql')";
    $result2 = mysql_query($q2);
        if($result2){
            $add_succes = true;
        }

    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/csTransPie.css" />
    <link rel="stylesheet" type="text/css" href="../css/smoothness/jquery-ui-1.8.18.custom.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.18.custom.min.js"></script>
    <script type="text/javascript" src="../js/csTransPie.js"></script>
    <script type="text/javascript">
        $(function() {
            $( "#add_multiserver" ).button();
        });
    </script>

</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content">
            <a style="float:right;" id="add_multiserver" href="multi_server.php?add_multiserver=true">Add server</a>
<div class="head_info">Please modify "FTP UPLOADS CONFIGURATIONS" from config.php to choose the best option for you !</div>
<br />


<?php
            if(isset($update_succes)) {
                echo "<p class='success'>Server updated succesfuly !</p>";
            }
            if(isset($add_succes)) {
                echo "<p class='success'>Server added succesfuly !</p>";
            }
            if(isset($_GET['msg'])){
                echo "<p class='success'>" . filter($_GET['msg']) . "</p>";
            }
            
if(!isset($_GET['id']) && !isset($_GET['add_multiserver'])) {
?>







            <?php
$q = "SELECT id, host FROM ftp_logins WHERE active = 1 ORDER BY id DESC";
            $result = mysql_query($q);
            if(mysql_num_rows($result) > 0) {
                    echo "<div id='users-contain' class='ui-widget'>
        <table id='users' class='ui-widget ui-widget-content'>
            <thead>
            <tr class='ui-widget-header '>
                <th>Active Servers</th>
                <th>Edit</th>
            </tr>
            </thead>
            <tbody>";
                    while($rowFTP = mysql_fetch_assoc($result)) {
                        echo "<tr><td><a class='nicelinks' href='multi_server.php?id=".$rowFTP['id']."'>" . $rowFTP['host'] . "</a></td> <td><a class='nicelinks' href='multi_server.php?id=".$rowFTP['id']."'><img border='0' src='../css/img/modify.gif' /></a></td></tr>";
                    }
                    echo "</tbody></table></div>";

            } else {
                echo "<p class='error'>No active servers</p>";
            }
            ?>



    <?php
    $q = "SELECT id, host FROM ftp_logins WHERE active = 0 ORDER BY id DESC";
    $result = mysql_query($q);
    if(mysql_num_rows($result) > 0) {
        echo "<div id='users-contain' class='ui-widget'>
        <table id='users' class='ui-widget ui-widget-content'>
            <thead>
            <tr class='ui-widget-header '>
                <th>Inactive Servers</th>
                <th>Edit</th>
            </tr>
            </thead>
            <tbody>";
        while($rowFTP = mysql_fetch_assoc($result)) {
            echo "<tr><td><a class='nicelinks' href='multi_server.php?id=".$rowFTP['id']."'>" . $rowFTP['host'] . "</a></td> <td><a class='nicelinks' href='multi_server.php?id=".$rowFTP['id']."'><img border='0' src='../css/img/modify.gif' /></a></td></tr>";
        }
        echo "</tbody></table></div>";

    } else {
        echo "<p class='error'>No inactive servers</p>";
    }

} elseif(isset($_GET['id']) && is_numeric($_GET['id']) && !isset($_GET['add_multiserver'])) { // end if is not set id
    $q = "SELECT * FROM ftp_logins
    INNER JOIN sources ON ftp_logins.source_id = sources.id
    WHERE ftp_logins.id = '{$_GET['id']}'";
    $result = mysql_query($q);
    if(!$result){
        echo mysql_error();
    }
    $rowFTP = mysql_fetch_assoc($result)
?>
    <form class="add_multiserver" action="" method="POST">
        <p>
            Host (Ex: "ftp.example.com"): <br />
            <input class="text" type="text" value="<?php echo $rowFTP['host']; ?>" name="host" /> </p>
        <p>
            User: <br />
            <input class="text" type="text" value="<?php echo $rowFTP['user']; ?>" name="user" /> </p>
        <p>
            Pass: <br />
            <input class="text" type="text" value="<?php echo $rowFTP['pass']; ?>" name="pass" /> </p>
        <p>
            Website URL till patch ("Ex: http://example.com/imagefolder"): <br />
            <input class="text" type="text" value="<?php echo $rowFTP['url']; ?>" name="url" /> </p>
        <p>
            Full FTP image patch: ("Ex: public_html/imagefolder/big") <br />
            <input class="text" type="text" value="<?php echo $rowFTP['img']; ?>" name="full_ftp_img_patch" /> </p>
        <p>
            Full FTP thumbnail patch ("Ex: public_html/imagefolder/small"): <br />
            <input class="text" type="text" value="<?php echo $rowFTP['thumb']; ?>" name="full_ftp_thumb_patch" /> </p>
        <p>
            Image patch ("Ex: big"): <br />
            <input class="text" type="text" value="<?php echo $rowFTP['img2']; ?>" name="img_patch" /> </p>
        <p>
            Thumbnail patch ("Ex: small"): <br />
            <input class="text" type="text" value="<?php echo $rowFTP['thumb2']; ?>" name="thumb_patch" /> </p>
        <p>

        <p>
            <input type="radio" name="active" <?php if($rowFTP['active'] == 0) {echo "checked=\"checked\"";} ?> value="0" /> Inactive <br />
            <input type="radio" name="active" <?php if($rowFTP['active'] == 1) {echo "checked=\"checked\"";} ?> value="1" /> Active <br />
        </p>

            <input type="hidden" value="<?php echo $rowFTP['source_id']; ?>" name="source_id" />
            <input class="submit" type="submit" name="update_server" value="Update Server" />
        </p>
        

    </form>
        <br />
            <form action="" method="POST">
                <input type="checkbox" name="confirm_delete_server" /> I confirm that i want to delete this server (ATENTION ! - deletion can make all images from specific server not reachable.) <br />
                <input type="submit" name="delete_server" value="Delete this server" />
            </form>
<?php
} elseif(isset($_GET['add_multiserver'])) {
    ?>
    <form class="add_multiserver" action="" method="POST">
        <p>
            Host (Ex: "ftp.example.com"): <br />
            <input class="text" type="text" name="host" /> </p>
        <p>
            User: <br />
            <input class="text" type="text" name="user" /> </p>
        <p>
            Pass: <br />
            <input class="text" type="text" name="pass" /> </p>
        <p>
            Website URL till patch ("Ex: http://example.com/imagefolder"): <br />
            <input class="text" type="text" name="url" /> </p>
        <p>
            Full FTP image patch: ("Ex: public_html/imagefolder/big") <br />
            <input class="text" type="text" name="full_ftp_img_patch" /> </p>
        <p>
            Full FTP thumbnail patch ("Ex: public_html/imagefolder/small"): <br />
            <input class="text" type="text" name="full_ftp_thumb_patch" /> </p>
        <p>
            Image patch ("Ex: big"): <br />
            <input class="text" type="text" name="img_patch" /> </p>
        <p>
            Thumbnail patch ("Ex: small"): <br />
            <input class="text" type="text" name="thumb_patch" /> </p>
        <p>
            <input class="submit" type="submit" name="add_new_server" value="Add Server" />
        </p>
    </form>
    <?php
}
    ?>

</div>
</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>