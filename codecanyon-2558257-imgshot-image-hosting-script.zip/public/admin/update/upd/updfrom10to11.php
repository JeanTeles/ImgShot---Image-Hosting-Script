<?php
mysql_query("CREATE TABLE IF NOT EXISTS `banned_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `reason` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");


mysql_query("CREATE TABLE IF NOT EXISTS `banned_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) NOT NULL,
  `reason` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");


mysql_query("CREATE TABLE IF NOT EXISTS `ipn_transactions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `amount` double NOT NULL,
  `date` date NOT NULL,
  `updFromDate` date NOT NULL,
  `updToDate` date NOT NULL,
  `payer_email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");


mysql_query("CREATE TABLE IF NOT EXISTS `private_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_from` bigint(20) NOT NULL,
  `id_to` bigint(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `readed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");

mysql_query("ALTER TABLE `users` DROP `banned`");
mysql_query("ALTER TABLE `users` ADD `premium` DATE NOT NULL AFTER `date`");
mysql_query("ALTER TABLE `users` ADD `ref` BIGINT(20) NOT NULL AFTER `unlock_code`");


mysql_query("UPDATE `update` SET update.value = '1.1' WHERE id = 1");

?>