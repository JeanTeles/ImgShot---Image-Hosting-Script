<?php

mysql_query("UPDATE `update` SET update.value = '1.2' WHERE id = 1");

?>