<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

$current_version = "1.2";
$q = "SELECT update.value FROM `update` WHERE id = 1";
$result = mysql_query($q);
if($result) {
    $rowUpdate = mysql_fetch_assoc($result);
} else {

    mysql_query("CREATE TABLE IF NOT EXISTS `update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;");

    mysql_query("INSERT INTO `update` (`id`, `name`, `value`) VALUES (1, 'version', '1.0');");

    die("Reload the page if it's first time you enter here, if not, an error occured.");
}

if($rowUpdate['value'] == '1.0' && isset($_GET['updatenow']) && $_GET['updatenow'] = 'upd'){
    include('upd/updfrom10to11.php');
    header('Location: index.php');
    exit();
}

if($rowUpdate['value'] == '1.1' && isset($_GET['updatenow']) && $_GET['updatenow'] = 'upd'){
    include('upd/updfrom11to12.php');
    header('Location: index.php');
    exit();
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../../css/grid.css" />
    <script type="text/javascript" src="../../js/jquery-1.7.1.min.js"></script>

</head>
<body>
<?php include("inc/menu.php"); ?>


<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo "../" . $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content" class="container_12">
            <div class="grid_7">
            <?php

            
            if($rowUpdate['value'] == $current_version){
                echo "<p class='success'>Your database is up to date</p>";
            } else {
                echo "<p class='error'>Your database version is not updated</p>";
            }

            ?>
            <table class='style2'>
                <tbody>
                <tr>
                    <td>Your version: </td>
                    <td><?php echo $rowUpdate['value']; ?></td>
                </tr>
                <tr>
                    <td>Latest version ready to install: </td>
                    <td><?php echo $current_version; ?></td>
                </tr>
                </tbody>
            </table>



            <?php
            if($rowUpdate['value'] !== $current_version){
                echo "<a href='index.php?updatenow=upd' class='button blue big'><span>Update database</span></a>";
            }
            ?>
            </div>
            <div class="grid_5">
                <h2>Update Instructions:</h2> <br />
                <hr>
                <ul class="style1">
                    <li>Copy/Replace folder public/admin/update</li>
                    <li>If database it's not up to date, click on <strong>Update database</strong> button (if you update from more older version, you may need to press the update database button more times, till database is up to date)</li>
                    <li>After database is updated, copy and replace all files from public without copying <strong>upload</strong> folder</li>
                    <li>I repeat, do not replace the upload folder, only the rest of the files</li>
                    <li>Remake config.php configurations</li>
                    <li>That's all ! If any problems, contact me on  <a target="_blank" class="style1" href="http://codecanyon.net/item/imgshot-image-hosting-script/discussion/2558257">CodeCanyon</a></li>
                </ul>
            </div>
            <div class="clear">&nbsp;</div>

        </div>

</div>

<?php include('../../inc/footer.php'); ?>

</body>
</html>