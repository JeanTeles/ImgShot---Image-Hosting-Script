<div id="content_menu">
    <div id="menu_links">
        <ul>
            <li><a href="index.php"><img border="0" style="position:absolute; margin-top:-5px;" src="../css/img/home.png" alt="H" /><span class="invisible">Home</span></a></li>
            <li><a href="stats.php">Stats</a></li>
            <li><a href="all_images.php">Images</a></li>
            <li><a href="search_moderate.php">Moderate</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="configs.php">Configs</a></li>
            <li><a href="multi_server.php">Multi Server</a></li>
            <li><a href="pages.php">Pages</a></li>
            <li><a href="maintenance.php">Maintenance</a></li>
            <li><a href="support_tickets.php">Support</a></li>
        </ul>
    </div>
</div>