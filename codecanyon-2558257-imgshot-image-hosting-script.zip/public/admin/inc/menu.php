<div id="menu">
    <div id="menu_links">
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../page-contact.html">Contact</a></li>
            <li><a href="../page-DMCA.html">DMCA</a></li>

            <?php if(isset($_SESSION['user_name'])) {
            ?>
            <li><a href="../myaccount.php">My Account</a></li>
            <li><a href="../logout.php">Log out</a></li>
            <?php
        } else {
            ?>
            <li><a href="../register.php">Register</a></li>
            <li><a href="../login.php">Login</a></li>
            <?php } ?>

            <?php
            if(isset($_SESSION['user_level']) && $_SESSION['user_level'] == 5){
                echo "<li><a href='index.php'>Admin Panel</a></li>";
            }
            ?>
        </ul>

    </div>
</div>

<div id="menubutton"><img id="menuactivate" border="0" src="css/img/menubutton.png" alt="menu button" /></div>
<script>
    $('#menubutton').click(function() {
        $('#menu').slideDown('slow', function() {
            // Animation complete.
        });
    });
</script>