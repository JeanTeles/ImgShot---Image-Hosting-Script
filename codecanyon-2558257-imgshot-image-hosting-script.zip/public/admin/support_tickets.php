<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}

$filters = "";

if(isset($_POST['ticket_username'])) {
    $ticket_username = filter($_POST['ticket_username']);
    $q = "SELECT id FROM users WHERE user_name LIKE '$ticket_username'";
    $result = mysql_query($q);
    if($result && mysql_num_rows($result) > 0) {
        $rowIdUsername = mysql_fetch_assoc($result);
        $filters .= " OR closed = 1 AND id_user = {$rowIdUsername['id']}";
    }
}

if(isset($_POST['ticket_userid']) && is_numeric($_POST['ticket_userid'])) {
    $q = "SELECT user_name FROM users WHERE id = {$_POST['ticket_userid']}";
    $result = mysql_query($q);
    if($result) {
        $rowNameUsername = mysql_fetch_assoc($result);
        $ticket_username = $rowNameUsername['user_name'];
        $filters .= " OR closed = 1 AND id_user = {$_POST['ticket_userid']}";
    }
}

if(isset($_GET['id'])){
    if(is_numeric($_GET['id'])) {
        $id = $_GET['id'];
        if(isset($_POST['submit_reply'])){
            $datetime = date('Y-m-d H:i:s');
            $replyMsg = filter($_POST['reply']);
            $q = "INSERT INTO tickets_reply (`id_ticket`, `id_user_reply`, `is_admin`, `message`, `date`) VALUES ('{$id}', '{$_SESSION['user_id']}', '1', '{$replyMsg}', '{$datetime}')";
            mysql_query($q);

            $q = "UPDATE tickets_opened SET closed = 0 WHERE id = '{$id}'";
            mysql_query($q);

            $q = "SELECT users.full_name, users.user_email FROM tickets_opened
             INNER JOIN users ON
             tickets_opened.id_user = users.id
            WHERE tickets_opened.id = '{$id}'";
            $result = mysql_query($q);
            $rowUser = mysql_fetch_assoc($result);
        sendMail($rowUser['user_email'], $rowUser['full_name'], 'New reply on your ticket #'.$id.'', 'You have a new reply in your ticket with id #'.$id.'. <br /> To view it you have to <a href="'.$site_url.'/login.php">login</a> and then <a href="'.$site_url.'/view_tickets.php?id='.$id.'">click here</a>.');
        }
        if(isset($_POST['close_ticket'])){
            $q = "UPDATE tickets_opened SET closed = 1 WHERE id = '{$id}'";
            mysql_query($q);
        }
        if(isset($_POST['open_ticket'])){
            $q = "UPDATE tickets_opened SET closed = 0 WHERE id = '{$id}'";
            mysql_query($q);
        }

    } else {
        header('Location: view_tickets.php');
        exit();
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/csTransPie.css" />
    <link rel="stylesheet" type="text/css" href="../css/grid.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="../js/csTransPie.js"></script>


</head>
<body>
<?php include("inc/menu.php"); ?>

<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content" class='container_12'>
            <?php
            if(isset($id)){
                $q = "SELECT * FROM tickets_opened WHERE tickets_opened.id = {$id}";
                $result = mysql_query($q);
                if(mysql_num_rows($result) > 0) {
                $rowTikOpen = mysql_fetch_assoc($result);
                switch($rowTikOpen['closed']){
                    case 0:
                        $tikStatus = "<span class='opened_ticket'>Opened</span>";
                        break;
                    case 1:
                        $tikStatus = "<span class='closed_ticket'>Closed</span>";
                        break;
                }
                echo "
                <p class='medium_head'>Ticket #{$rowTikOpen['id']} {$tikStatus}</p>
                <p class='medium_head'>Subject: {$rowTikOpen['name']}</p>
                ";

                $q = "SELECT tickets_reply.message, tickets_reply.is_admin, users.full_name FROM tickets_reply
                INNER JOIN users ON tickets_reply.id_user_reply = users.id
                WHERE tickets_reply.id_ticket = {$id}
                ORDER BY tickets_reply.id ASC";
                $result = mysql_query($q);
                if($result) {
                    while($rowTikReply = mysql_fetch_assoc($result)){
                        if($rowTikReply['is_admin'] == 1){
                            $admin_sign = "<img src='".$site_url."/css/img/star_full.png' />";
                        } else {
                            $admin_sign = "";
                        }
                        echo "<div class='ticket_reply'><div class='user'>$admin_sign {$rowTikReply['full_name']}</div><div class='message'>{$rowTikReply['message']}</div></div>";
                    }

                    echo "
                    <form action='' method='POST'>
                        <p><textarea cols='79' name='reply'></textarea></p>
                        <input type='submit' value='Reply' name='submit_reply' />
                    </form>
                    <br />
                    <form action='' method='POST'>
                        <input type='submit' value='Close Ticket' name='close_ticket' />
                        <input type='submit' value='Open Ticket' name='open_ticket' />
                    </form>
                    ";


                } else {
                    echo mysql_error();
                }
            } else {
                    echo "<p class='error'>Invalid ticket id</p>";
                }
            }


            if(!isset($_GET['id'])){
                ?>
                <div class="grid_4">
                <form method="GET" action="">
                        <p> Search ticket by id: <br />
                        <input type="text" name="id" />
                            <input type="submit" />
                        </p>
                </form>

                </div>
                <div class="grid_4">
                    <form method="POST" action="">
                    <p> Search tickets by user name: <br />
                        <input type="text" name="ticket_username" />
                        <input type="submit" />
                    </p>
                    </form>

                </div>
                <div class="grid_4">
                    <form method="POST" action="">
                    <p> Search tickets of user id: <br />
                        <input type="text" name="ticket_userid" />
                        <input type="submit" />
                    </p>
                    </form>
                </div>

                    <hr />
                    <div class="clear">&nbsp;</div>
                        <div class="grid_12">


                <?php
                if(isset($ticket_username)) {
                    echo "<h2>Viewing all tickets of user: {$ticket_username}</h2>";
                }
            $q = "SELECT * FROM tickets_opened WHERE closed = 0 $filters";
                //echo $q;
            $result = mysql_query($q);
            while($rowTikOpen = mysql_fetch_assoc($result)) {
                echo "<a class='ticket_opened' href='support_tickets.php?id=".$rowTikOpen['id']."'>Ticket #".$rowTikOpen['id']." - ".$rowTikOpen['name']."</a>";
            }}
            ?>
        </div>
            <div class="clear">&nbsp;</div>

        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>