<?php
/**
 * Created by Zamfi
 * Image Hosting Script
 * more informations about this script on
 * http://imagehost.iuhu.org
 * Copyright of Zamfirescu Alexandru Costin - © Iuhu 2012 - All rights reserved
 * Copyright notice - Zamfi Image Hosting Script

 * This script and its content is copyright of Zamfirescu Alexandru Costin - © Iuhu 2012. All rights reserved.
 * Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:
 * This script is for personal and comercial use only.
 * You may not, except with our express written permission, distribute or commercially exploit the content.
 * You may you transmit it or store it in any other website or other form of electronic retrieval system.
 **/


require_once('../config.php');
$dbconnect = new db();
$dbconnect->connect();


$login = new login();
$login->page_protect();
if (!$login->checkAdmin()) {
    die("Acces forbitten");
    exit;
}
$todayDate = date('Y-m-d');

$userCount = mysql_query("SELECT COUNT(id) FROM users");
$userCount = mysql_fetch_assoc($userCount);
$userCount = $userCount['COUNT(id)'];

$userPremiumCount = mysql_query("SELECT COUNT(id) FROM users WHERE premium >= '$todayDate'");
$userPremiumCount = mysql_fetch_assoc($userPremiumCount);
$userPremiumCount = $userPremiumCount['COUNT(id)'];

$userRegularCount = $userCount - $userPremiumCount;

$imagesCount = mysql_query("SELECT COUNT(id) FROM images");
$imagesCount = mysql_fetch_assoc($imagesCount);
$imagesCount = $imagesCount['COUNT(id)'];

$imagesAdultCount = mysql_query("SELECT COUNT(id) FROM images WHERE adult = 1");
$imagesAdultCount = mysql_fetch_assoc($imagesAdultCount);
$imagesAdultCount = $imagesAdultCount['COUNT(id)'];

$imagesCleanCount = $imagesCount - $imagesAdultCount;

$galleriesCount = mysql_query("SELECT COUNT(id) FROM galleries");
$galleriesCount = mysql_fetch_assoc($galleriesCount);
$galleriesCount = $galleriesCount['COUNT(id)'];

$PMCount = mysql_query("SELECT COUNT(id) FROM private_messages");
$PMCount = mysql_fetch_assoc($PMCount);
$PMCount = $PMCount['COUNT(id)'];

$bannedIPCount = mysql_query("SELECT COUNT(id) FROM banned_ip");
$bannedIPCount = mysql_fetch_assoc($bannedIPCount);
$bannedIPCount = $bannedIPCount['COUNT(id)'];

$bannedUserCount = mysql_query("SELECT COUNT(id) FROM banned_users");
$bannedUserCount = mysql_fetch_assoc($bannedUserCount);
$bannedUserCount = $bannedUserCount['COUNT(id)'];

$multiserverCount = mysql_query("SELECT COUNT(id) FROM ftp_logins");
$multiserverCount = mysql_fetch_assoc($multiserverCount);
$multiserverCount = $multiserverCount['COUNT(id)'];



?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $site_title; ?></title>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="description" content="<?php echo $site_meta_description; ?>" />
    <meta name="keywords" content="<?php echo $site_meta_keywords; ?>" />
    <meta name="author" content="<?php echo $site_meta_author; ?>" />
    <link rel="stylesheet" type="text/css" href="../css/styles.css" />
    <link rel="stylesheet" type="text/css" href="../css/grid.css" />
    <script type="text/javascript" src="../js/jquery-1.7.1.min.js"></script>

    <script type="text/javascript" src="http://www.google.com/jsapi"></script>
    <script type="text/javascript">
        google.load('visualization', '1', {packages: ['corechart']});
    </script>
    <script type="text/javascript">
        function drawVisualization() {
            // Create and populate the data table.
            var data = google.visualization.arrayToDataTable([
                ['', ''],
                <?php echo "['Adult Images', {$imagesAdultCount}],"; ?>
                <?php echo "['Clean Images', {$imagesCleanCount}]" ?>
            ]);

            // Create and draw the visualization.
            new google.visualization.PieChart(document.getElementById('visualization')).
                draw(data, {title:"Images (Adult vs Clean)"});
        }


        google.setOnLoadCallback(drawVisualization);
    </script>

    <script type="text/javascript">
        function drawVisualization() {
            // Create and populate the data table.
            var data = google.visualization.arrayToDataTable([
                ['', ''],
            <?php echo "['Regular Users', {$userRegularCount}],"; ?>
            <?php echo "['Premium Users', {$userPremiumCount}]" ?>
            ]);

            // Create and draw the visualization.
            new google.visualization.PieChart(document.getElementById('visualization2')).
                draw(data, {title:"Users (Regular vs Premium)"});
        }


        google.setOnLoadCallback(drawVisualization);
    </script>




</head>
<body>
<?php include("inc/menu.php"); ?>


<div id="container">
    <div id="logo">
        <a href="index.php"><img border="0" alt="logo" src="<?php echo $logo_location; ?>" /></a>
    </div>

        <?php include('inc/admin_menu.php'); ?>
        <div id="content" class="container_12">
            <div class="grid_12"><h2>Overall Statistics: </h2> <hr></div>
            <div class="clear">&nbsp;</div>

            <div class="grid_5">
                <table class='style2'>
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Total</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Images: </td>
                        <td><?php echo $imagesCount; ?></td>
                    </tr>
                    <tr>
                        <td>Images Adult: </td>
                        <td><?php echo $imagesAdultCount; ?></td>
                    </tr>
                    <tr>
                        <td>Images Clean: </td>
                        <td><?php echo $imagesCleanCount; ?></td>
                    </tr>
                    <tr>
                        <td>Users: </td>
                        <td><?php echo $userCount; ?></td>
                    </tr>
                    <tr>
                        <td>Users Premium: </td>
                        <td><?php echo $userPremiumCount; ?></td>
                    </tr>
                    <tr>
                        <td>Galleries: </td>
                        <td><?php echo $galleriesCount; ?></td>
                    </tr>
                    <tr>
                        <td>Private Messages: </td>
                        <td><?php echo $PMCount; ?></td>
                    </tr>
                    <tr>
                        <td>Banned IP's: </td>
                        <td><?php echo $bannedIPCount; ?></td>
                    </tr>
                    <tr>
                        <td>Banned Users: </td>
                        <td><?php echo $bannedUserCount; ?></td>
                    </tr>
                    <tr>
                        <td>Multi Servers: </td>
                        <td><?php echo $multiserverCount; ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="grid_7">
                <div id="visualization"></div>
                <div id="visualization2"></div>
            </div>
            <div class="clear">&nbsp;</div>

            <div class="grid_12">
                <h2>Top 15 most viewed images</h2><hr>
<table class='style2'>
    <thead>
<tr>
    <th>View id</th>
    <th>Image views</th>
    <th>Adult img</th>
    <th>Uploaded by user</th>
</tr>
    </thead>
    <tbody>


                <?php
                $q = "SELECT images.views, images.view_id, images.adult, users.user_name, users.id as userid FROM images
                LEFT JOIN users ON images.id_user = users.id
                ORDER BY images.views DESC LIMIT 15";
                $result = mysql_query($q);
                while($rowImages = mysql_fetch_assoc($result)) {
                    $adult = "No";
                    switch($rowImages['adult']){
                        case 0:
                            $adult = "No";
                            break;
                        case 1:
                            $adult = "Yes";
                            break;
                    }
                    echo "<tr><td><a class='style1' target='_blank' href='../img-{$rowImages['view_id']}.html'>{$rowImages['view_id']}</td><td>{$rowImages['views']}</td><td>{$adult}</td><td><a class='style1' target='_blank' href='users.php?id={$rowImages['userid']}'>{$rowImages['user_name']}</a></td></tr>";
                }
                ?>
    </tbody>
</table>

            </div>
            <div class="clear">&nbsp;</div>

        </div>

</div>

<?php include('../inc/footer.php'); ?>

</body>
</html>